# SEO Audit

Site taşıma (yenileme) projeleri için teknik SEO aracı. Kişisel proje.

Araç iki iş yapar:

1. **Site denetimi.** Bir siteyi tarar, teknik SEO sorunlarını bulur ve her sorunu doğru ekibe verir.
2. **Taşıma projesi.** Eski siteyi ve yeni siteyi karşılaştırır, 301 listesini üretir, yapılacak işleri çıkarır, canlıya çıkışı kontrol eder ve çıkıştan sonra taşımayı canlıda doğrular.

Araç yerel bilgisayarda veya kendi sunucunuzda çalışır. Sürüm `package.json` dosyasındadır. Kararların geçmişi `CLAUDE.md` → Karar günlüğü bölümündedir.

```mermaid
flowchart LR
  A[Eski siteyi tara] --> C[Eşleştir]
  B[Yeni siteyi tara] --> C
  C --> D[301 haritası]
  D --> E[Yapılacaklar]
  E --> F[Canlıya çıkış listesi]
  F --> G[Canlı doğrulama]
```

## Araç ne yapar

### Tam yaptığı işler

Bu işlerin kodu ve testi tamamdır. Gerçek sitelerde ölçüm sürüyor (bkz. Doğrulama).

| İş | Sonuç |
|---|---|
| Siteyi tarar | Linkleri ve sitemap dosyalarını izler. Her yönlendirme adımını kaydeder. robots.txt kurallarına uyar. Şifreli staging sitesini tarar. Eski Türkçe kodlamaları (windows-1254) okur. |
| Teknik sorunları bulur | 97 kural, 16 kategori. Her sorunun açıklaması, çözümü, önemi (kritik, uyarı, bilgi) ve ekibi (Frontend, Backend, İçerik, SEO) vardır. |
| Site ayarlarını kontrol eder | http/https ve www sürümleri, SSL sertifikası, HSTS, sıkıştırma, llms.txt, kırık dış link, kırık ve büyük görsel. |
| Eski ve yeni siteyi eşleştirir | Eski sitenin her bölümü için yeni yeri önerir. Birden çok yeni siteyi destekler (örnek: diller ayrı alan adlarına gider). Sayfanın dilini kullanır. |
| 301 listesini üretir | Adresi değişen her sayfaya yeni sayfa önerir: slug, title, H1 ve içerik benzerliği, güven seviyesi ile. Siz onaylarsınız. Araç listeyi CSV olarak verir (301 ve 410). |
| 301'leri staging'de kontrol eder | Her eski adresi yeni sitede ister. Sonuç: 301 kurulu, 301 eksik, hedef yok, zincir veya geçici yönlendirme. |
| Linksiz eski sayfaları bulur | Search Console, Analytics veya backlink dışa aktarımını (CSV) ya da düz adres listesini alır. Taramada olmayan adresleri eski sitede ister. Açılan sayfa eski sayfa olur ve 301 haritasına girer. 301 haritası trafiğe göre sıralanır ("1.240 tıklama"). |
| İşleri yere ve ekibe göre ayırır | Eski alan adı sunucusu, her yeni site, içerik ve karar bekleyen işler ayrı kartlardır. |
| Canlıya çıkışı kontrol eder | Staging adresi kalmış mı (canonical, hreflang, link, görsel, sitemap, 301 listesi), staging Google'a açık mı, noindex ve `Disallow: /` nerede, Analytics/GTM ve Search Console etiketi yeni sitede var mı. |
| Taşımayı canlıda doğrular | Çıkıştan sonra her eski adresi canlı alan adında ister: 301 doğru mu, zincir, geçici yönlendirme, yanlış hedef, hedef hatalı, 410 geldi mi, kayıp sayfa. Canlı siteyi ayrıca tarar: noindex, X-Robots-Tag, `Disallow: /` ve staging adresi kalmış mı, etiketler var mı, sitemap canlı adresleri mi içeriyor ve adresler 200 mü. |
| JavaScript sitesini okur (isteğe bağlı, sadece yerel) | Sayfayı Chromium ile açar, JS çalışınca oluşan title, H1, içerik ve linkleri okur. Ham HTML ile farkı raporlar: sadece JS ile gelen title, H1, içerik ve link, JS ile değişen etiket, JS'nin kaldırdığı noindex. Bkz. JavaScript render. |
| Rapor verir | Web arayüzü, Excel (site denetimi ve taşıma projesi), 301 listesi CSV, ham JSON. |
| Paylaşılabilir rapor verir | Müşteri veya ekip için tek HTML dosyası: özet, sağlık skoru, kritik işler, ekip başına işler (Backend, Frontend, İçerik, SEO), taşıma durumu, adres listeleri. Sunucuda kalmaz. PDF için tarayıcıda yazdırın. Bkz. Paylaşılabilir rapor. |

### Kısmen yaptığı işler

| İş | Sınır |
|---|---|
| 301 önerisi | Aynı kelimeyi, ortak öneki ve yakın yazımı bulur. Farklı dildeki eş anlamı bulmaz (göz kapağı ↔ blepharoplasty). Bu sayfalarda adresi siz seçersiniz. |
| 301 listesi biçimi | Sadece CSV. `.htaccess`, nginx veya Shopify biçimi yok. |
| Etiket kontrolü | Analytics ve GTM kimliğini HTML içindeki script'ten okur. Consent aracı ile yüklenen etiketi sadece JavaScript render açıksa görür. |
| JavaScript render | Chromium ayrı kurulur. Yayın modunda (Render) kapalı. Gerçek sitelerde henüz denenmedi: süre ve yanlış alarm ölçülmedi. Google'ın render davranışının tahminidir, kopyası değildir. |
| Şifreli staging'de 301 kontrolü | Araç şifreyi saklamaz. Şifreli sitede bu kontrol "Kontrol edilemedi" sonucunu verir. |
| Büyük site | Varsayılan sınır 5.000 URL, en fazla 50.000. Araç bütün taramayı bellekte tutar: çok büyük sitede yavaşlar. |
| Title genişliği | Piksel değeri tahmindir. |
| Eski adres listesi | Dosya ile çalışır: Search Console ve Analytics hesabına bağlanmaz (API yok). Search Console zip dosyası açılmaz: içindeki `Pages.csv` dosyasını seçin. Sütun adları gerçek bir dışa aktarım ile henüz denenmedi: bulunamayan sütunu siz seçersiniz. Çıkıştan sonra eklenen adres eski sitede istenmez: içeriksiz eski sayfa olur, 301 önerisi sadece adres benzerliğidir. Eski sitede yönlenen adres 301 haritasına girer, ama zincirin ara adımları satır almaz ve staging durumu sadece staging taraması o adresi bulduysa görünür (yeni istek yok). |

### Yapmadığı işler

- Varsayılan taramada JavaScript çalıştırmaz. JS ile oluşan içerik için "JavaScript ile oluştur" seçeneğini açın.
- Search Console, Analytics veya backlink aracına bağlanmaz (API ve hesap bağlantısı yok). Trafik verisini sadece yüklenen dosyadan okur.
- Site denetimindeki sorunları trafiğe göre sıralamaz. Sadece taşıma projesinin 301 haritası trafiğe göre sıralanır.
- Hız ölçmez (Core Web Vitals).
- Anahtar kelime ve sıralama takibi yapmaz.
- Zamanlanmış tarama ve izleme yapmaz.
- Raporu bir link ile paylaşmaz. Rapor indirilen bir dosyadır.
- Sorunları ClickUp'a görev olarak açmaz (sıradaki sürüm).
- Metin veya etiket önerisi yazmaz (AI yok).

## Kurulum

Node.js 20 veya üstü gerekli.

```bash
npm install
npm test     # bütün testler, yaklaşık 45 saniye
npm start
```

Ayarlar (port, şifre, Chromium yolu, sonra API anahtarları) kök klasördeki `.env` dosyasında durur: `cp .env.example .env`. Araç bu dosyayı açılışta okur. Kabukta yazılan değer `.env` değerinden önce gelir. `.env` depoya girmez.

Tarayıcıda `http://localhost:3300` adresini açın. Giriş ekranında iki seçenek var: "Site denetimi" ve "Taşıma projesi".

Arayüz koyu temadır. Yazı tipi Google Fonts'tan (Archivo) gelir. İnternet yoksa araç sistem yazı tipini kullanır.

## Site denetimi

1. Adresi yazın. "Taramayı başlat" düğmesine basın.
2. Tarama sırasında her URL bir hücredir. Gri: 200. Turuncu: yönlendirme. Kırmızı: 4xx veya 5xx. Boş kırmızı çerçeve: bağlantı hatası. Boş gri çerçeve: robots engeli.
3. Tarama bitince "Sorunlar" sekmesi açılır. Önem ve ekip filtrelerini kullanın. Soruna tıklayın: açıklama, çözüm ve etkilenen adresler görünür.
4. Site kartı ek kontrollerin sonucunu gösterir. Renkli kutuya tıklayın, ilgili sorun açılır.
5. "Sayfalar" sekmesinde tablo vardır. Satıra tıklayın, sayfanın bütün verisi açılır. Render açıksa "JavaScript" satırı ham HTML ile render sonucunu yan yana gösterir.
6. "Excel indir" raporu verir. Sayfalar: Özet, Sorunlar, Sorun detayları, Sayfalar, JavaScript farkı (sadece render taramasında), Redirectler, Hatalar, Engelli (robots), Sitemap dosyaları, Site sürümleri, Dış kaynaklar.

### Sağlık skoru

Skor = kritik sorunu olmayan URL oranı (robots ile engelli URL'ler hariç). Site geneli kritik sorun varsa (örnek: robots.txt siteyi kapatıyor) skor en fazla 40 olur.

### Denetim kuralları

97 kural, 16 kategori: tarama ve indeks, redirect, canonical, title, meta description, başlık hiyerarşisi, içerik (kopya, benzer, dummy metin), linkler (kırık, staging linki), görseller, hreflang, yapısal veri, performans, HTTPS, mobil ve erişilebilirlik, URL yapısı, JavaScript.

Kural tanımları `src/rules/definitions.js` dosyasındadır.

### Eşikleri ayarlama

Bütün eşikler `config/rules.json` dosyasındadır. Kodu değiştirmeyin. Örnekler:

- Az içerik sınırı: `"thinContentWords": 250`
- Title uzunluğu: `"titleMaxPx": 580`
- Benzer içerik hassasiyeti: `"nearDuplicateDistance": 5` (küçük sayı = daha katı)
- Büyük görsel sınırı: `"largeImageKb": 200`
- SSL uyarı süresi: `"sslExpiryDays": 30`
- Kırık sayılmayan kodlar: `"brokenIgnoreStatuses": [401, 403, 429, 999]`
- Bir kuralı kapatma: `"rules": { "title-equals-h1": { "enabled": false } }`
- Önem değiştirme: `"rules": { "canonical-missing": { "severity": "notice" } }`

Dosyayı değiştirince sunucuyu yeniden başlatmanız gerekmez. Araç eski taramaları açarken yeni ayarlar ile tekrar denetler.

### Ek kontroller

Tarama bittikten sonra çalışır. Arayüzde "Gelişmiş ayarlar" altından, komut satırında `--no-checks` ile kapanır.

- **Site ayarları:** http/https ve www sürümleri ana adrese 301 ile gidiyor mu? SSL sertifikası geçerli mi, kaç gün kaldı? HSTS başlığı var mı? `/llms.txt` var mı?
- **Dış linkler:** araç her dış linki bir kez HEAD ile ister. Sunucu HEAD isteğini reddederse 1 baytlık GET ile tekrar dener.
- **Görseller:** kırık görsel ve büyük dosya (varsayılan 200 KB üstü).
- **Sıkıştırma:** ek istek gerekmez. Araç taramada her sayfanın `content-encoding` başlığını okur.

Kurallar:

- 401, 403, 429, 999 kodları ve zaman aşımı "kırık" sayılmaz. Bunlar genelde bot korumasıdır.
- Araç DNS kaydı olmayan bir alan adını bir kez sorgular.
- Limitler `config/rules.json` → `checks` bölümündedir: paralel istek 8, zaman aşımı 8 sn, en fazla 1.000 dış link ve 2.000 görsel.

### JavaScript render

Sadece yerel modda çalışır (`npm start`). Yayın adresinde (Render) kapalıdır.

React, Vue veya Next.js (istemci tarafı) ile oluşan sitede ham HTML boştur. Araç title, H1 ve içeriği bulamaz ve JS ile gelen linkleri izlemez. Bu seçenek sayfayı gerçek bir tarayıcıda (Chromium) açar.

Kurulum (bir kez, yaklaşık 260 MB disk):

```bash
npm install                                         # playwright-core (isteğe bağlı paket) gelir
npx playwright-core install chromium-headless-shell # Chromium
```

Kurulu Chrome kullanmak için `CHROMIUM_PATH` ortam değişkenine yolunu yazın (denenmedi). Chromium yoksa seçenek kapalı görünür ve nedenini yazar. Araç normal taramaya devam eder.

Kullanım: arayüzde "Gelişmiş ayarlar" → "JavaScript ile oluştur". Taşıma projesinde her sitenin kendi kutusu var (Tarama adımı): eski site ham, yeni site render olabilir. Komut satırında `--render`.

```mermaid
flowchart LR
  A[Ham HTML isteği] --> B[Ham alanlar]
  A --> C[Chromium: JS çalışır]
  C --> D[Render alanları]
  B --> E[Birleşim + fark]
  D --> E
  E --> F[JavaScript kuralları]
```

| Alan | Kaynak |
|---|---|
| Title, description, canonical, H1–H6, içerik, linkler, görseller, JSON-LD, hreflang, Open Graph | Render |
| Durum kodu, yönlendirme, HTTP başlıkları, boyut, süre, render engelleyen kaynak | Ham |
| noindex, Analytics/GTM kimliği, staging adresi | İkisinin birleşimi (ham HTML'deki noindex Google'da render'ı durdurabilir) |

JavaScript kuralları: title sadece JS ile, H1 sadece JS ile, içerik çoğunlukla JS ile, iç linkler çoğunlukla JS ile, JS SEO etiketini değiştiriyor, ham noindex'i JS kaldırıyor (kritik), sayfa render edilemedi, JS veya CSS robots.txt ile engelli. Ham taramada site JS kabuğu gibi görünürse araç "Site JavaScript ile oluşuyor olabilir" der ve projede render ile tekrar taramayı önerir.

Güvenlik ve veri:

- Tarayıcı ağa kendisi çıkmaz. Her istek araçtaki tek bir kontrol noktasından geçer: host izni, robots.txt, iç ağ engeli (SSRF), zaman aşımı, 5 MB gövde sınırı. Yönlendirmenin her adımı kontrol edilir. WebSocket ve service worker kapalıdır.
- Sadece taranan site ve alt alan adları açılır. Başka alan adı (CDN) için "İzinli dış alan adları" alanına yazın. Analytics, reklam, sosyal medya ve font servisleri her zaman engelli (`render.blockHosts`). Görsel, video ve font hiç istenmez. Engellenen istekler raporda sayılır.
- Staging şifresi sadece taranan siteye gider.
- Sayfanın kendisi tekrar istenmez: tarayıcı ham okumanın HTML'ini kullanır.
- Her sayfa yeni ve boş bir tarayıcı bağlamında açılır (çerez yok).

Hız: sayfa başına en az 0,6 sn (ağ 500 ms sessiz kalınca render biter). Aynı anda 2 sayfa. Gerçek sitede sayfa başına 1–5 sn bekleyin (ölçülmedi). Bir taramada en fazla 1.000 sayfa render edilir, sonrası ham okunur. Ayarlar `config/rules.json` → `render`.

## Taşıma projesi

Giriş ekranında "Taşıma projesi" seçin ve proje adını yazın. Araç yedi adımda yol gösterir. Her ekranda tek bir "Sıradaki iş" kartı durur: tek cümle ve tek düğme. Her terimin yanında "?" açıklaması vardır.

| Adım | Ne yapılır |
|---|---|
| Proje | "Yeni yapı nasıl?" sorusunu cevaplayın: "Tek alan adı" veya "Diller ayrı alan adlarına". Siteleri yazın: eski site (canlı), eski alan adına geçecek site (staging olabilir), ek siteler (en fazla 3; örnek: Türkçe site ayrı alan adında). Ek site için canlı alan adını yazın. |
| Tarama | Her site için "Tara" düğmesi vardır. Var olan bir taramayı da bağlayabilirsiniz. Staging şifresini tarama ayarlarına yazın. Araç şifreyi saklamaz. İsteğe bağlı: "Eski adres listesi" kartı (aşağıda). |
| Eşleştirme | Eski sitenin her bölümü (`/tr/`, `/fr/`…) bir satırdır. Araç yeni yeri önerir ve seçili getirir. Bulamadığı bölüm "Bulunamadı" der: satırı açın ve sayfaları görün. Karar yanlış görünürse (dil farkı, sıfır sayfa) araç uyarır ve daha iyi seçimi söyler. Serbest kural "Gelişmiş" altındadır. |
| 301 haritası | Adresi değişen her sayfa için araç yeni sayfa önerir. Güven: Yüksek, Orta, Düşük. Öneriyi onaylayın, başka sayfa seçin, adres yazın veya 410 verin. Araç Türkçe sayfaya Türkçe sayfa önerir. Eski ana sayfaya doğru sitenin ana sayfasını önerir. Ana sayfaya toplu yönlendirme önermez (soft 404). Eski sitede yönlenen adres "Eski yönlendirme" sekmesinde durur ve hedefinin kararını izler (aşağıda). "CSV indir" son listeyi verir. Kararlar projede saklanır. |
| Yapılacaklar | İşler yapıldığı yere göre kartlardır: eski alan adı sunucusu (301, yönlendirme düzeltmesi, 410), her yeni site (sayfa oluşturun, link verin), İçerik (title, meta, H1, noindex) ve Karar bekleyen. Her kart ekibi gösterir. Listede "Canlı adres" (301 hedefi) ve "Kontrol edilen adres" (staging) ayrı sütunlardır. Yeni sitede çok az sayfa varsa araç "hazır değil gibi görünüyor" der ve o sitenin işlerini saymaz. Site gerçekten küçükse uyarıyı kapatın. |
| Canlıya çıkış | Staging taramalarından çıkış öncesi liste. Dört grup: **Kritik** (301 listesinde veya sitede açık yazılmış staging adresi; şifresiz ve Google'a açık staging), **Karar bekleyen** (301 haritasında açık satır), **Çıkış anında değiştirin** (noindex, X-Robots-Tag, `Disallow: /`: staging'de normaldir), **Kontrol edin** (Analytics/GTM kimliği ve Search Console etiketi yeni sitede var mı). Göreli adres sorun değildir. Durum her zaman taramadan gelir: düzeltin, sonra tekrar tarayın. |
| Canlı doğrulama | Site canlıya çıkınca "Canlıya çıktık" düğmesi ile çıkış gününü işaretleyin. Araç eski site ve staging taramalarını kilitler. Sonra her siteyi "Canlıda tara" ile tarayın. Dört grup: **Kritik** (301 yok ve hata, hedef hatalı, staging'e giden 301, kayıp sayfa, canlıda noindex, `Disallow: /`, staging adresi), **Düzeltin** (zincir, 302/307, yanlış hedef, 410 yerine başka yanıt, eksik etiket, sitemap hatası), **Kontrol edilemedi** (canlı alan adı yok, canlı tarama yok, erişim engeli; tamam sayılmaz), **Tamam**. |

**Eski alan adına geçecek site:** canlıdan sonra eski alan adını bu site kullanır. Bütün 301'ler bu sitede kurulur.

**301 hedefi her zaman canlı alan adıdır.** Staging sadece karşılaştırma ve test içindir. Araç staging adresini asla canlı adres olarak yazmaz.

### Eski adres listesi

Araç eski sayfaları link ve sitemap ile bulur. Hiçbir sayfanın link vermediği ama trafik alan sayfa taramada yoktur. Bu sayfa 301 almaz ve canlıdan sonra 404 verir. Liste bu sayfaları bulur.

| Adım | Ne olur |
|---|---|
| Liste ekleyin | Tarama adımında "Eski adres listesi" kartını açın. CSV seçin veya adresleri yapıştırın. Kaynak: Search Console (Performans → Sayfalar → Dışa aktar, `Pages.csv`), Analytics (sayfa yolu), backlink aracı (hedef adres) veya her satırda bir adres. Ayırıcı virgül veya noktalı virgül. Araç sütunları tanır (Türkçe ve İngilizce adlar). Bulamazsa sütunu siz seçersiniz. En fazla 5 liste. |
| Temizlik | www ve http/https aynı sitedir. İzleme parametreleri (utm_, gclid…) silinir. Aynı adres birleşir: tıklama ve gösterim toplanır. Başka alan adındaki adres ayrılır ve kontrol edilmez. Dosya adresleri (pdf, görsel) atlanır. |
| Eski sitede isteyin | Araç sadece taramada olmayan adresleri ister. İstek sadece eski siteye gider. Başka alan adına giden yönlendirme izlenmez. robots.txt ayarı tarama ayarlarından gelir. Yayın modunda en fazla `yayin.maxUrls` adres istenir: trafiği yüksek olan önce. |
| Sonuç | Taramada vardı, Yeni bulundu (HTML 200: eski sayfa olur), Eski sitede hata (404, 410), Eski sitede yönleniyor (301 haritasında satır alır), Yönleniyor · hedef hata (haritaya girmez), HTML değil, Yanıt yok, robots.txt engeli. Yeni bulunan sayfa eşleştirmeye, 301 haritasına, yapılacaklara, canlıya çıkış listesine ve canlı doğrulamaya girer. |
| Trafik | Sıra: tıklama, sonra gösterim, sonra görüntüleme, sonra link veren alan adı. Trafiği olmayan satır sonra gelir. 301 haritasında her durum sekmesi, Yapılacaklar'da her yer kartı, Canlıya çıkış listesinde "Karar bekleyen" satırları ve Canlı doğrulamada her grup bu sıradadır. Satır "1.240 tıklama" etiketi taşır. Excel'de bu sayfalarda Tıklama, Gösterim, Görüntüleme ve Link veren alan adı sütunları vardır (listede olan ölçüler). Listeden gelen sayfa "Listeden" işareti taşır. |

Liste değişince 301 kararları kalır. Bir listeyi kaldırırsanız onun sayfaları haritadan düşer, karar "artık gerekli değil" sayılır. Liste geri gelince karar tekrar kullanılır.

"Canlıya çıktık" işaretinden sonra araç eski sitede istek atmaz: eski alan adı artık yeni siteyi sunar. Liste taraması da kilitlenir.

Eski sitede hiç istenmeyen adres (çıkıştan sonra eklenen veya çıkıştan önce eklenip istenmeyen) "Canlıda kontrol edilir" sonucunu alır:

| Adım | Ne olur |
|---|---|
| Eşleştirme | Adres içeriksiz eski sayfa olur. Araç staging'e istek atmaz. Sayılara (eski sayfa sayısı, korunan oran) girmez. |
| 301 haritası | Satır "İçerik yok" etiketi taşır. Öneri sadece adres benzerliğidir (title, H1 ve içerik yok). Kontrol edip karar verin. |
| Canlı doğrulama | Araç adresi canlı alan adında ister. Açılıyor veya tek adımda yönleniyorsa Tamam. Hata veriyorsa: listede trafik varsa Kritik "Kayıp sayfa", yoksa Kontrol edilemedi "Eski sitede var mıydı bilinmiyor" (liste bozuk olabilir). Eşik: `rules.json` → `urlList.lateProof`. |

### Eski sitede yönlenen adres

Eski site bir adresi başka adrese yönlendiriyorsa (`/indirim → /kampanya`), canlıdan sonra eski sunucu kuralları kalmaz ve adres 404 verir. Araç bu adres için 301 haritasına satır ekler. Satır son hedefin yeni adresine tek adımda gider (`/indirim → /yeni/kampanya`, zincir yok). Kaynak: eski taramada link ile bulunan yönlendirme ve listedeki yönlenen adres. Yönlenen adres eski sayfa sayılmaz.

| Son hedefin durumu | Satır |
|---|---|
| Kural, onaylı karar veya yeni sitede aynı yolda | 301 → hedefin canlı adresi ("İzliyor"). CSV kaynağı "Eski yönlendirme" |
| 410 kararı | 410 |
| Karar yok veya kontrol edilemedi | "Bekliyor". Hedef karar alınca satır da değişir. Ayrıca karar saymaz |
| Ana sayfa | 301 → ana sayfa, soft 404 uyarısı ile |
| Eski sayfa değil (linksiz hedef, dosya) | Hedefin adresinden öneri. Onay bekler |
| Başka alan adı | Aynı dış adres önerilir. Onay bekler. Staging alan adı ise öneri yok |
| Eski sitede hata veriyor | Satır yok. Liste "Yönleniyor · hedef hata" der |
| Yeni sitede aynı adreste sayfa var | Satır yok |

Satır kendi kararını saklamaz. Hedefin kararı değişince satır da değişir. "Başka adres seç" ile satıra kendi kararınızı verirsiniz. "Geri al" satırı tekrar izlemeye döndürür. Staging taraması bu adresi yönlendirme olarak bulduysa satır "Staging'de kurulu" veya "Staging başka adrese gidiyor" der. Yapılacaklar'da satır sunucu işidir ("301 kurun"). Canlı doğrulamada beklenen hedef tek adımdır. Onaylı dış adres canlıda Location ile karşılaştırılır: araç dış alan adına istek atmaz ("301 doğru · dış hedef").

Liste müşteri verisidir. Sunucuda `crawls/projects/lists/` klasöründe durur ve depoya girmez. "Projeyi indir" listeyi (adres ve trafik) taşır. Sayfa içeriği taşınmaz.

### Sayfa grupları

| Grup | Anlamı |
|---|---|
| Aynı kaldı | Aynı yolda açılıyor. Title, meta description ve H1 aynı. |
| İçerik değişti | Aynı yolda açılıyor ama title, meta veya H1 farklı. Alan boşaldıysa veya noindex eklendiyse "kayıp" olur. |
| Hedef hazır, 301 kurulu | Taşınan sayfanın hedefi var. Eski adres hedefe 301 veriyor. Zincir veya 302 varsa satır yapılacak işi yazar. |
| Hedef hazır, 301 eksik | Hedef var. Eski adres yönlenmiyor veya başka sayfaya gidiyor. |
| Hedef yok | Taşınan sayfanın hedefi yeni sitede yok. |
| Yönleniyor | Aynı yol yeni sitede başka bir adrese yönleniyor. Hedef 4xx veya 5xx ise "hedef hatalı". |
| Açılıyor, link yok | Adres açılıyor ama yeni sitede bu sayfaya hiç link yok. |
| Kayboldu | Yeni sitede 404 veya başka bir hata. 301 gerekir. |
| Bölüm kaldırıldı | "Bölüm kaldırıldı" kararı verilen bölümün sayfası. 301 veya 410 yine gerekir. |
| Kontrol edilemedi | robots.txt engeli, şifreli staging (401) veya bağlantı hatası. |

### 301 kontrolü ve "Tekrar kontrol et"

Yeni tarama eski adresleri bulamaz, çünkü yeni sitede onlara link yoktur. Bu yüzden araç gereken her eski adresi yeni sitede tek tek ister. İlk eşleştirme birkaç saniye sürebilir. Araç sadece projedeki sitelere istek gönderir.

Araç bu yanıtları 30 dakika saklar (`rules.json` → `compare.probeCacheMin`). Sunucuda 301 kurduysanız adım çubuğunun altındaki "Tekrar kontrol et" düğmesine basın. Araç adresleri tekrar ister. Yeni tarama gerekmez. Satır son kontrolün saatini gösterir.

### Canlı doğrulama

Çıkıştan sonra eski alan adı yeni siteyi sunar. Bu yüzden eski site taraması çıkıştan önceki taramadır ve tekrar yapılmaz. "Canlıya çıktık" işareti bu taramayı kilitler. İşaret hiçbir kontrolün sonucunu değiştirmez. İşareti geri alabilirsiniz.

Beklenen liste çıkış öncesi taramalardan ve 301 haritasındaki kararlardan gelir. Araç staging'e istek atmaz: staging çıkıştan sonra kapanabilir. Listede her eski sayfa vardır: 301 ve 410 kararları, kurallar, staging'de aynı adreste açılan sayfalar (200 beklenir) ve kararı olmayan sayfalar.

Araç her eski adresi canlı alan adında ister ve yönlendirmeyi elle izler. İstek sadece projedeki canlı alan adlarına gider. Başka alan adına giden adım istenmez. Yayın modunda SSRF koruması her adımda çalışır. Sonuç 30 dakika saklanır (`compare.probeCacheMin`). "Tekrar kontrol et" adresleri hemen tekrar ister. Haritada bir karar değişirse araç listeyi hemen tekrar kontrol eder.

Canlı alan adı yazılmamış ek site kontrol edilemez. Ekran nedeni ve sıradaki işi yazar. Eski adreslerin çoğu yönlenmeden 200 veriyorsa araç "eski alan adı hâlâ eski siteyi sunuyor olabilir" der (`rules.json` → `verify`).

### Proje dosyası ve Excel

Proje sunucuda `crawls/projects/` klasöründe durur. Projede sonuç yoktur, sadece tanım vardır: siteler, roller, tarama kimlikleri (staging ve canlı ayrı), kurallar, 301 kararları, çıkış günü ve rapor adları (müşteri, hazırlayan). Eski adres listesi ayrı dosyadadır (`crawls/projects/lists/`). "Projeyi indir" JSON dosyasını verir (liste dahil), "Proje yükle" geri yükler.

Proje Excel'inin sayfaları: Özet, Yapılacaklar, Canlıya çıkış, Canlı doğrulama (çıkıştan sonra), Kaybolan, Yönlenen, İçerik değişimi, Taşınan, Linksiz, Bölüm kaldırıldı, Kontrol edilemedi, Yeni sayfalar, Kurallar, 301 haritası, Eski adres listesi, Öneriler. Boş gruplar için sayfa oluşmaz. Liste varsa "301 haritası", "Yapılacaklar", "Canlıya çıkış" ve "Canlı doğrulama" sayfalarında trafik sütunları vardır. "301 haritası" sayfasında "Eski sayfa nereden" sütunu da vardır (Tarama, Eski adres listesi veya Liste (çıkıştan sonra, içerik yok)).

### Paylaşılabilir rapor

Excel teknik kişi içindir. Rapor müşteri veya ekip içindir: kısa ve okunur. Site denetimi ve taşıma projesi ekranında "Rapor indir" düğmesine basın. Panelde üç seçim var:

| Seçim | Anlamı |
|---|---|
| Kim okuyacak? | "Müşteri": kural kimliği yok, listede en fazla 20 satır. "Ekip": kural kimliği var, en fazla 50 satır (`rules.json` → `report.listLimit`). |
| Müşteri adı | Raporun en üst satırı. İsteğe bağlı. |
| Hazırlayan | Rapor tarihinin yanında görünür. İsteğe bağlı. |

Taşıma projesinde iki ad projeye kaydedilir ve "Projeyi indir" dosyası onları taşır.

Raporun bölümleri:

| Bölüm | Site denetimi | Taşıma projesi |
|---|---|---|
| Özet cümle ve 4 sayı | Sağlık skoru, taranan adres, kritik sorun, uyarı | Korunan sayfa, sağlık skoru (yeni site), kritik iş, açık iş |
| Kritik işler | Kritik kurallar | Çıkıştan önce: Canlıya çıkış listesinin kritik işleri. Çıkıştan sonra: Canlı doğrulamanın kritik işleri. |
| Ekip başına işler | Kritik ve uyarı kuralları (bilgi notları Excel'de) | Çıkıştan önce: Yapılacaklar ve Canlıya çıkış. Çıkıştan sonra: Canlı doğrulama. |
| Taşıma durumu | — | Altı adımın durumu |
| Adres listeleri | Kapalı gelir, başlığa tıklayın | Kapalı gelir, başlığa tıklayın |

Ekip adları: ekranda "CMS" olan iş raporda Backend, "Siz" olan iş (karar) raporda SEO olur (`rules.json` → `report.teams`).

Sağlık skoru (taşıma projesi): çıkıştan önce yeni sitenin staging taramasından gelir. Staging robots.txt Google'ı kapatıyorsa bu kural skoru 40 ile sınırlamaz (`report.stagingRules`): ayar çıkışta değişir. Rapor bunu not olarak yazar. Çıkıştan sonra canlı tarama varsa skor ondan gelir.

Güvenlik: rapor tek HTML dosyasıdır ve script içermez. Taranan siteden gelen her metin kaçış ile basılır. Dosyadaki `Content-Security-Policy` etiketi script, dış istek ve form çalıştırmaz. Sunucu raporu her istekte üretir ve diske yazmaz. Yayın modunda da çalışır (rapor gizli bilgi içermez).

PDF: dosyayı tarayıcıda açın, listeleri açın, sonra yazdırın ("PDF olarak kaydet"). Kapalı liste bazı tarayıcılarda kapalı yazdırılır.

## Komut satırı

```bash
node bin/crawl.js https://www.ornek.com
```

Taşıma için iki tarama yapın ve etiket kullanın. Sonra arayüzde projeye bağlayın.

```bash
# Eski site (canlı)
node bin/crawl.js https://www.ornek.com --label eski

# Yeni site (staging, şifreli, robots kapalı)
node bin/crawl.js https://staging.ornek.com --label yeni --auth kullanici:sifre --ignore-robots
```

Çıktılar `crawls/` klasörüne gider: `<host>_<etiket>_<tarih>.json` (ham veri; taşıma projesi bu dosyayı kullanır, silmeyin) ve aynı adla `.xlsx` (Excel rapor).

| Seçenek | Açıklama | Varsayılan |
|---|---|---|
| `--max` | En fazla URL | 5000 |
| `--depth` | En fazla link derinliği | 50 |
| `-c` | Paralel istek | 5 |
| `--delay` | İstekler arası bekleme (ms) | 0 |
| `--timeout` | İstek zaman aşımı (ms). Sayfanın gövdesini de kapsar. | 15000 |
| `--auth` | Basic auth `user:pass` | — |
| `--ignore-robots` | robots.txt kurallarını yok say | kapalı |
| `--no-sitemap` | Sitemap okuma | açık |
| `--no-checks` | Ek kontrolleri çalıştırma | açık |
| `--no-external` | Dış linkleri kontrol etme | açık |
| `--no-images` | Görselleri kontrol etme | açık |
| `--user-agent` | Özel user-agent | `SEO-Audit/<sürüm>` |
| `--render` | Sayfaları Chromium ile aç (JavaScript render) | kapalı |
| `--render-allow` | Render için izinli dış alan adları (virgül ile) | — |
| `--label` | Dosya adı etiketi | — |
| `--out` | Çıktı klasörü | crawls |

Sunucu yavaş ise `-c 2 --delay 500` kullanın.

## Tarama davranışı

- `www` olan ve olmayan host aynı site sayılır. Alt alan adları ayrı sitedir.
- Araç `utm_*`, `gclid`, `fbclid` parametrelerini ve `#` parçasını siler.
- Araç görsel, PDF, CSS, JS gibi dosyaları taramaz. Dış linkleri kaydeder ama taramaz.
- Sitemap adresleri link taramasından sonra taranır. Linki olmayan sitemap sayfası "yetim" olur.
- Yönlendirme döngüsü ve 10 adımdan uzun zincir hatadır.
- Staging şifresi sadece taranan siteye gider. Başka hosta giden yönlendirme veya sitemap şifreyi almaz.
- Araç 5 MB üstündeki sayfayı ve sitemap dosyasını keser.
- robots.txt kontrolü aracın kendi user-agent değeri ile yapılır. Googlebot'a kapalı site ayrı bir kural ile raporlanır.
- noindex okuması: araç yönergeleri tek tek okur. `max-image-preview:none` noindex değildir. Başka bir bota yazılan `X-Robots-Tag` sayılmaz.

Her URL için toplanan veri: durum kodu, her yönlendirme adımı, son hedef, title, meta description, başlık ağacı (H1–H6), canonical, meta robots, X-Robots-Tag, html lang, hreflang, kelime sayısı, içerik parmak izi, görseller ve alt metinleri, iç ve dış linkler, iç link sayısı, derinlik, yanıt süresi, boyut, sıkıştırma, JSON-LD tipleri, Open Graph, Analytics/GTM kimlikleri, Search Console etiketi, sitemap ve yetim durumu. Render açıksa ayrıca: ham HTML değerleri (title, H1, description, canonical, robots, kelime, iç link), sadece JS ile gelen linkler, render süresi, engellenen istekler.

## Sunucuda çalıştırma

Varsayılan olarak araca sadece bu bilgisayardan erişilir. Ekibin erişmesi için:

```bash
HOST=0.0.0.0 PORT=3300 APP_USER=admin APP_PASS=guclu-bir-sifre npm start
```

veya Docker ile:

```bash
docker build -t seo-audit .
docker run -d -p 3300:3300 -v $(pwd)/crawls:/app/crawls -e APP_USER=admin -e APP_PASS=guclu-bir-sifre seo-audit
```

| Değişken | Açıklama | Varsayılan |
|---|---|---|
| `PORT` | Port | 3300 |
| `HOST` | Dinlenen adres | 127.0.0.1 |
| `APP_USER`, `APP_PASS` | Arayüz şifresi. Sunucuyu ağa açarsanız tanımlayın. | — |
| `ALLOWED_HOSTS` | Sunucuyu bir alan adı ile açarsanız (örnek: `seo.ofis.example`) adı yazın. Virgül ile ayırın. `localhost` ve IP adresi için gerekmez. | — |
| `MAX_JOBS` | Aynı anda çalışan tarama sayısı | 2 |
| `CRAWL_DIR` | Kayıt klasörü | ./crawls |
| `PUBLIC_MODE` | `1` = yayın modu (aşağıda) | — |
| `EPHEMERAL_STORAGE` | `1` = arayüz "disk kalıcı değil" uyarısı gösterir | — |
| `ENV_FILE` | Başka bir `.env` dosyası (testler kullanır) | ./.env |

Güvenlik:

- Yerel sunucu sadece `localhost`, IP adresi veya `ALLOWED_HOSTS` içindeki ad ile açılır.
- Sunucu başka bir siteden gelen yazma isteğini (POST, PUT, DELETE) reddeder. Tarayıcıda açık olan başka bir site taramalarınızı okuyamaz ve tarama başlatamaz.
- Araç taranan siteden gelen her metni arayüzde güvenli biçimde basar.

Araç taramayı sunucu tarafında yapar. Sadece tarayıcıda çalışan bir sayfa olamaz, çünkü tarayıcılar başka sitelerin içeriğini okumayı engeller (CORS).

### Yayın (Render, ücretsiz plan)

Render kodu GitHub deposundan alır ve her commit sonrası yeni sürümü yayınlar. Ayarlar `render.yaml` dosyasındadır.

1. render.com adresinde GitHub hesabınız ile giriş yapın.
2. New → Blueprint seçin. `seo-audit` deposunu seçin.
3. Apply düğmesine basın. Birkaç dakika sonra adres hazır olur.

Yayın modu (`PUBLIC_MODE=1`):

- İç ağ adreslerini taramaz: `localhost`, `10.x`, `172.16-31.x`, `192.168.x`, `169.254.x` ve IPv6 iç adresleri (SSRF koruması). Araç yönlendirmenin her adımını da kontrol eder.
- Şifre isteğe bağlıdır. Şifresiz yayında herkes projeleri görür, indirir ve siler: **müşteri sitesi taramayın, müşteri işlerini yerelde yapın.** Şifre için Render → Environment bölümüne `APP_USER` ve en az 10 karakterli `APP_PASS` ekleyin.
- Limitler: bir taramada en fazla 2.000 URL, aynı anda 1 tarama (`config/rules.json` → `yayin`).
- `/healthz` adresi her zaman şifresizdir ve sadece "ok" döner.
- JavaScript render kapalıdır. Docker imajı isteğe bağlı paketleri kurmaz (`npm ci --omit=optional`).

Ücretsiz planın sınırları: sunucu 15 dakika istek gelmezse uyur. Sunucu uyuyunca veya yeniden başlayınca taramalar ve projeler silinir. Excel'i ve proje dosyasını hemen indirin.

### Tanıtım sayfası

`docs/index.html` statik bir tanıtım sayfasıdır. Tarama yapmaz. Yayın: GitHub Pages (Settings → Pages → Deploy from a branch → main, /docs) veya Netlify (yayın klasörü `docs`, build komutu yok).

## Doğrulama

Bu komut aracın sonuçlarını Screaming Frog ile karşılaştırır. Amaç: aracın nerede yanlış veya farklı okuduğunu bulmak.

1. Siteyi araç ile tarayın. Tarama kimliği adres çubuğundadır (`#/crawl/<kimlik>`) ve `crawls/<kimlik>.json` dosyasının adıdır.
2. Aynı siteyi Screaming Frog ile tarayın. Ayarlar: robots.txt'ye uy, Rendering "Text Only", alt alan adları kapalı.
3. Screaming Frog'da Internal sekmesi → filtre "All" → Export. Dosyayı CSV olarak kaydedin.
4. Komutu çalıştırın:

```bash
npm run dogrula -- <tarama kimliği> /yol/internal_all.csv
```

Komut özet tablosunu yazar ve iki dosya üretir: `crawls/dogrulama-<host>.json` (özet) ve `crawls/dogrulama-<host>.csv` (bütün farklar, Excel ile açılır). Dosyalar depoya girmez.

Karşılaştırılan alanlar: durum kodu, yönlendirme hedefi, title, meta description, ilk H1, canonical, meta robots, indekslenebilirlik, kelime sayısı, iç link sayısı, derinlik, title piksel genişliği. Sayı alanlarında küçük fark sayılmaz (`rules.json` → `validate`). Komut referans dosyasında bulamadığı sütunları uyarı olarak yazar.

Durum: komut hazır. Gerçek sitelerdeki ilk ölçüm bekliyor.

## Geliştirme

### Testler

`npm test` on beş test dosyası çalıştırır (yaklaşık 50 saniye). Testler internete çıkmaz: yerel test siteleri kullanır.

| Test | Kontrol | Kapsam |
|---|---|---|
| Crawler | 22 | Tarama, şifrenin sadece taranan siteye gitmesi, gövde zaman aşımı ve boyut sınırı, sitemap entity koruması |
| Kural | 117 | `test/fixture-rules.js` her kuralı bilerek bozan sayfalardan oluşur. Her kural doğru sayfada tetiklenmeli. `/temiz` sayfasında hiç sorun çıkmamalı (yanlış alarm kontrolü). SSL ve HSTS kuralları self-signed bir HTTPS test sitesi ile denenir. JavaScript kuralları ayrı bir render taramasında denenir: `/temiz` render modunda da temiz kalmalı. Excel "JavaScript farkı" sayfası. |
| Yayın modu | 12 | İç ağ adresleri, şifre kuralları, `/healthz`, limitler |
| Karşılaştırma | 49 | Yol eşleşmesi, kaybolan, yönlenen, içerik kaybı, yol kuralları, çoklu hedef, 301 kontrolü, Excel |
| 301 haritası | 17 | Öneri puanı, dil filtresi, ana sayfa, kararlar, CSV |
| Yapılacaklar | 8 | İşlerin yeri, site hazırlık uyarısı, canlı adres |
| Proje | 20 | Tanım, kayıt, API, "Tara" düğmesi, eşleştirme, proje dosyası |
| Canlıya çıkış | 11 | Dört test sitesi. Temiz staging hiçbir iş üretmemeli. |
| Sunucu | 8 | Host ve Origin kontrolü, istek boyutu, "Tekrar kontrol et", çıkış işareti ve kilit, canlı tarama, canlı doğrulama ucu ve Excel, tarama kimliği (IPv6 varsa 9 kontrol) |
| Doğrulama | 8 | CSV okuyucu, referans sütunları, alan karşılaştırması |
| Canlı doğrulama | 12 | Bozuk ve temiz canlı site. Her sonuç türü, SSRF, kontrol sınırı. Temiz canlı site hiçbir iş üretmemeli. |
| Eski adres listesi | 30 | Search Console (TR, EN), Analytics, backlink ve düz liste okuma, temizlik, birleştirme, linksiz sayfanın eski sitede bulunması, sadece eski siteye istek, trafik sırası (301 haritası, Yapılacaklar, Canlıya çıkış, Canlı doğrulama), Excel, proje dosyası, karar korunur, çıkıştan sonra eski siteye ve staging'e istek yok, çıkıştan sonra gelen adres canlıda kontrol edilir (kanıtlı ve kanıtsız). Örnek CSV test içinde üretilir. |
| JavaScript render | 17 | Ham ↔ render birleşimi, host politikası, liste modu, tarayıcı yokken ham devam, yayın modunda kapalı, proje ayarı ve çıkıştan sonra kilit. Chromium ile: 13 yolda SSRF (iç sunucuya 0 istek), izin listesindeki host da korumadan geçer, şifre sadece taranan siteye, engel listesi, geç gelen içerik, önbellek, robots.txt, gövde ve sayfa sınırı |
| Paylaşılabilir rapor | 14 | Ekip çevirisi, başlık alanları, kural seçimi (bilgi girmez), XSS (taranan siteden zararlı title, adres ve proje adı: script, olay özniteliği ve `javascript:` linki yok), CSP başlığı ve etiketi, kitle farkı ve liste sınırı, boş sütun, staging skoru, dosya adı, `.env` okuma (kabuk değeri önce gelir), taranmamış projede 409, adların kaydı ve proje dosyası, çıkıştan önce ve sonra proje raporu |
| Eski yönlendirme | 13 | Yönlendirme verisi (aynı yol, dış adres, kırık hedef, zincir), tarama ve listeden gelen yönlendirme, hedefin kararını izleme (301, 410, bekler, kendi kararı ve geri alma), ana sayfa uyarısı, dış adres ve staging adresi, staging durumu, Yapılacaklar, CSV ve Excel, liste değişince karar kalır, canlı doğrulama beklentisi, staging'e ve çıkıştan sonra eski siteye istek yok |

Chromium yoksa (örnek: GitHub Actions) tarayıcı gerektiren 22 kontrol "atlandı" yazar ve test geçer. Tarayıcısız kontroller her yerde çalışır. Actions'ta da çalışması için iş akışına `npm test` öncesi `npx playwright-core install --with-deps chromium-headless-shell` adımı eklenebilir (elle, denenmedi).

Kurallar:

- Yeni kural için test sitesine onu tetikleyen bir sayfa ve bir beklenti ekleyin.
- Eşikleri koda yazmayın, `config/rules.json` içine yazın.
- Depoya `.env`, API anahtarı, şifre, müşteri verisi veya tarama sonucu koymayın. Depo herkese açıktır.

### Depoyu güncelleme

Güncelleme tek bir zip dosyası ile gelir (`seo-audit-vX.Y.Z.zip`). Zip dosyasını **açmadan** deponun kök klasörüne yükleyin (Add file → Upload files) ve commit yapın.

`.github/workflows/guncelle.yml` iş akışı gerisini yapar: zip dosyasını açar, dosyaları doğru klasörlere yazar, `SIL.txt` içindeki dosyaları siler, testleri çalıştırır ve sonucu commit eder. Testler geçmezse depo değişmez ve Actions sekmesi kırmızı olur.

## Sınırlar (bilinçli)

- JavaScript ile oluşan içerik sadece "JavaScript ile oluştur" açıkken görünür. Yayın modunda (Render) bu seçenek kapalıdır. Render sonucu Google'ın render sonucunun tahminidir: kullanıcı etkileşimi (tıklama, kaydırma) yapılmaz.
- `srcset` ve CSS arka plan görselleri kontrol edilmez. Sadece `<img src>` kontrol edilir.
- `.xml.gz` sitemap okunmaz.
- HTTP başlığındaki canonical okunmaz.
- SSRF koruması adresi istekten önce DNS ile kontrol eder. DNS cevabı istek anında değişirse (DNS rebinding) koruma bunu yakalamaz.
- Veritabanı yoktur. Her tarama bir JSON dosyasıdır.
- Paylaşılabilir rapor bir link değildir. Dosyayı siz gönderirsiniz. Logo alanı yok.

## Yol haritası

Tamamlanan:

- Tarama, web arayüzü, Excel
- Kural motoru (97 kural), sağlık skoru, ek kontroller
- Yayın modu (Render), SSRF koruması
- Taşıma projesi: eşleştirme, 301 haritası, yapılacaklar, canlıya çıkış listesi, canlı doğrulama
- Kod incelemesi ve güvenlik düzeltmeleri, doğrulama komutu
- Eski adres listesi (dosya ile): linksiz eski sayfaları bulma, bütün listeler trafiğe göre sıralı, çıkıştan sonra gelen adresler canlı doğrulamada
- Eski sitede yönlenen adres için 301: son hedefin yeni adresine tek adım
- JavaScript render (Playwright, isteğe bağlı, sadece yerel): ham HTML ile render farkı, sadece JS ile gelen linkler
- Paylaşılabilir rapor (tek HTML dosyası, müşteri ve ekip için)

Sıradaki işler (sıra ile):

1. Doğrulama: üç gerçek taramada Screaming Frog ile karşılaştırma
2. ClickUp işi: sorunları ve taşıma işlerini görev olarak açma (Free plan sınırı: dakikada 100 istek)
3. Canlıdan sonra izleme (1, 7 ve 30 gün)

Sonra konuşulacak: AI önerileri (title, meta, alt metin, anlam benzerliği ile 301 eşleştirme), Core Web Vitals.

Yapılmayacak: anahtar kelime takibi, backlink veritabanı. Bu veri hazır servislerden alınır.
