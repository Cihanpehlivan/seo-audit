# SEO Audit — Proje bağlamı

Bu dosya projenin hafızasıdır. Her sohbete ve her geliştirme oturumuna bu dosyayı okuyarak başla. Her sprint sonunda "Durum" ve "Karar günlüğü" bölümlerini güncelle.

## Amaç

Kişisel proje. Teknik SEO denetim aracı. Bir şirkete veya ajansa bağlı değildir. Web sitesi yenileme projelerinde teknik SEO denetimi yapar.

Ana değer: yenileme (migration) güvenliği. Eski siteyi canlıdan önce tara, yeni siteyi staging'de tara, farkı bul, 301 haritasını üret, canlıya çıkışı kontrol et.

Kullanıcı: proje sahibi (Cihan). Sorunlar iş alanına göre gruplanır (Frontend, Backend/CMS, İçerik, SEO). Böylece her sorun doğru kişiye iletilir. Paylaşılabilir rapor (v0.14.0) müşteri ve ekip için tek HTML dosyasıdır. ClickUp görevi v0.14.1'de gelir.

## Mimari

- Node.js 20+, ES modules, framework yok. Bağımlılıklar: cheerio, robots-parser, exceljs, fast-xml-parser. İsteğe bağlı (v0.13.0): playwright-core 1.63.0 (kesin sürüm, `optionalDependencies`). Chromium ayrı kurulur (`npx playwright-core install chromium-headless-shell`) veya `CHROMIUM_PATH`.
- Tarama sunucu tarafında yapılır. Tarayıcı içinde çalışamaz (CORS). Bu yüzden yayınlanmış bir web sayfası değil, yerel bilgisayarda veya kendi sunucusunda çalışan bir Node uygulamasıdır.
- Veri: `crawls/` klasöründe her tarama için `<id>.json` (ham), `<id>.meta.json` (özet), `<id>.audit.json` (denetim). Veritabanı yok.
- Ham veri: `{ meta, pages, checks }`. `checks` ek kontrol sonucudur (`ran`, `site`, `resources`, `limited`). v0.4 öncesi taramalarda `checks` yoktur; ilgili kurallar o taramalarda tetiklenmez.

```
bin/crawl.js            CLI
scripts/dogrula.js      Doğrulama komutu (v0.10.2): `npm run dogrula -- <tarama> <internal_all.csv>`. Mantık `src/validate.js` içinde (CSV okuyucu, referans sütunları, alan karşılaştırması)
src/crawler.js          Tarama motoru: kuyruk, redirect zinciri (manuel), robots, sitemap, iptal. v0.12.0: liste modu (`seeds`): sadece verilen adresler, link ve sitemap yok, başka hosta yönlendirmede durur (`offHost`). v0.13.0: `render` seçeneği (`{ allowHosts, limits }`), `request(url, init)` render kontrol noktası için, `guard` seçeneği (test), `meta.render`
src/render.js           JavaScript render (v0.13.0): `renderStatus` (paket ve Chromium var mı, yayın modunda kapalı), `createRenderer` (tarama başına bir tarayıcı, sayfa başına yeni bağlam, ölü vekil, kontrol noktası `context.route`), `makeHostPolicy`, `cleanAllowHosts`, `mergeRender` (ham ↔ render birleşimi, `raw` özeti, `metaRobotsJs`, `link.js`)
src/env.js              `.env` okuyucu (v0.14.0): `loadEnv(file)` → `process.loadEnvFile`. Sunucu ve CLI açılışta çağırır. Kabuktaki değer (boş da) kalır. Dosya yoksa sessiz. `ENV_FILE` başka dosya (testler)
src/report.js           Paylaşılabilir rapor (v0.14.0): `siteReport`, `projectReport` (model, sade veri), `renderReport` (HTML, script yok, CSP meta), `teamOf` (ekip çevirisi `report.teams`), `stagingScore`, `cleanReportInfo`, `reportFileName`, `REPORT_HEADERS`. Her birimde sabit `key` (ClickUp için, v0.14.1)
src/urllist.js          Eski adres listesi (v0.12.0): sütun tanıma (`rules.json` → `urlList.columns`), temizlik, kaynak birleştirme, istek listesi (taramada olmayanlar, trafik sırası), eski sayfa kümesine ekleme (`withListPages`), sonuç sınıfları. İstek atmaz. CSV okuyucu `validate.js` ile paylaşılır. v0.12.1: trafik sırası (`byTraffic`, `sortByTraffic`), geç adres (`latePaths`, `withLatePages`: içeriksiz eski sayfa, `late: true`), kanıt (`hasProof`, `urlList.lateProof`). v0.12.2: eski yönlendirmeler (`redirectInfo`, `oldRedirects`: eski tarama + liste taraması, istek yok)
src/compare.js          Eski taramayı bir veya daha çok yeni tarama ile karşılaştırır. Yol kuralları, desen önerisi, satır açıklaması, bölüm tablosu (v0.7.1: her bölümün sayfa listesi). Bulunamayan eski yolları beklenen adreste yoklar. Taşınan sayfada hedefi ve geçecek sitedeki 301'i kontrol eder (v0.7.0). v0.12.1: geç sayfa (`late`) istek almaz, içerik farkı aranmaz, sayılara girmez (`summary.late`)
src/projects.js         Taşıma projesi: tanım doğrulama, site anahtarı → alan adı çevirisi, dosya kaydı (crawls/projects/<id>.json, atomik yazma), 301 haritası kararlarının temizliği. v0.12.0: eski adres listesi ayrı dosya (crawls/projects/lists/<id>.json, `getList`, `updateList`)
src/launch.js           Canlıya çıkış listesi (v0.10.0): staging taramalarından kritik, karar, çıkışta değişecek ve kontrol işleri. v0.11.0: ortak fonksiyonlar (makeIsStaging, stagingAddresses, indexBlockers, tagCheck) canlı doğrulama ile paylaşılır
src/verify.js           Canlı doğrulama (v0.11.0): beklenen liste (istek yok), canlı istekler (sadece canlı alan adları), canlı tarama bulguları, gruplar (Kritik, Düzeltin, Kontrol edilemedi, Tamam). v0.12.1: trafik sırası, geç adres kanıtı (`late-unproven`). v0.12.2: eski yönlendirme satırları beklenen listede, dış hedef sonucu `ok-left`
src/todo.js             Yapılacaklar (v0.9.0): işleri yere göre gruplar (eski alan adı sunucusu, her yeni site, İçerik, Karar bekleyen), site hazırlık kontrolü. v0.12.1: yer, sonra trafik sırası
src/redirectmap.js      301 haritası (v0.8.0): bulunamayan eski sayfaya yeni sayfa önerisi (slug, title, H1, içerik; IDF ağırlığı), güven, kullanıcı kararları, CSV. v0.8.1: dil filtresi (html lang), eski ana sayfaya ana sayfa önerisi. v0.12.2: eski yönlendirme satırı (`kind: 'follow'`, durum `follow` veya `wait`): son hedefin kararını izler
src/netguard.js         Yayın modunda iç ağ adreslerini engeller (SSRF koruması)
src/checks.js           Ek kontroller (tarama sonrası): site sürümleri, SSL, HSTS, llms.txt, dış link, görsel
src/parser.js           HTML → SEO alanları (başlık ağacı, JSON-LD, görseller, linkler, parmak izi)
src/fingerprint.js      exactHash + 64-bit simhash (BigInt yok)
src/normalize.js        URL normalizasyonu, iç/dış ayrımı (www = aynı site)
src/sitemap.js          sitemap + sitemap index. v0.10.1: entity genişletmez (processEntities: false), standart entity'leri elle çözer
src/rules/definitions.js  97 kural (tek kaynak). v0.13.0: kategori `js` (9 kural)
src/rules/helpers.js    isIndexable, titlePx, staging host tespiti, isBroken, TLS hata metinleri
src/rules/index.js      Denetim motoru, sağlık skoru
src/export.js           Excel çıktısı
src/store.js            Dosya tabanlı kayıt
src/server.js           Web sunucusu + API (/api/crawls, /api/projects, /api/compare, /api/rules, /api/info, /healthz) + SSE canlı ilerleme. PUBLIC_MODE=1 yayın modudur. v0.10.1: Host ve Origin kontrolü (ALLOWED_HOSTS), istek sınırı `server.maxBodyKb`
                        /api/projects/:id/map → GET (harita, ?format=csv son liste), POST { set: { "/eski/yol": karar | null } }
                        /api/projects/:id → crawl (POST), match (v0.10.0: `launch` alanı), excel, export. GET/PUT/DELETE tanım
                        /api/projects/:id/ready → POST { site, ok } (v0.9.0): hazır görünmeyen siteyi bu tarama için hazır say
                        /api/projects/:id/match?fresh=1 (v0.10.1): eski adresleri tekrar ister. Yanıtta `checkedAt` var. Kayıtlı sonuç `compare.probeCacheMin` dakika geçerlidir
                        /api/projects/:id/launch (v0.11.0) → POST { at } çıkış işareti ve kilit, DELETE işareti kaldırır
                        /api/projects/:id/crawl { site, live: true } (v0.11.0) → canlı tarama (ayrı kimlik: liveCrawlId)
                        /api/projects/:id/verify[?fresh=1] (v0.11.0) → canlı doğrulama. Çıkış işareti yoksa 409, need: ["launch"]
                        /api/projects/:id/urllist (v0.12.0) → GET görünüm (kaynaklar, sayılar, satırlar), POST { text, name?, file?, columns?, preview? } kaynak ekler, DELETE [/<kaynak>] kaldırır
                        /api/crawls/:id/report ve /api/projects/:id/report (v0.14.0) → GET ?kitle=musteri|ekip&musteri=&hazirlayan= HTML indirme (attachment, CSP başlığı). Proje: taranmamışsa 409. Proje adları `project.report` (PUT ile değişir)
                        /api/projects/:id/urllist/fetch (v0.12.0) → POST { ignoreRobots } taramada olmayan adresleri eski sitede ister (liste taraması, etiket `liste`). Çıkıştan sonra 409, need: ["no-launch"]
render.yaml             Render Blueprint (ücretsiz plan, Docker)
.github/workflows/guncelle.yml  Güncelleme zip dosyasını uygular (v0.10.3): köke yüklenen `*.zip` açılır, test edilir, commit edilir. Bkz. Çalışma döngüsü 7. adım
docs/                   Landing page (v0.8.3): docs/index.html + docs/img/. GitHub Pages (main, /docs) veya Netlify ile yayınlanır. Uygulamadan bağımsız, tarama yapmaz
public/                 Arayüz (vanilla JS, build yok, koyu tema). Giriş ekranı = landing page (Site denetimi / Taşıma projesi). Proje ekranı: adım çubuğu + Sıradaki iş kartı
config/rules.json       Bütün eşikler, kural ayarları ve ek kontrol limitleri (checks)
test/                   fixture sunucuları ve testler (fixture-https.js: self-signed HTTPS test sitesi, fixture-migration.js: eski site + geçecek site (v0.12.0: linksiz eski sayfalar, v0.12.1: `/gec-sayfa`), server-test.js: yerel sunucu güvenliği, "Tekrar kontrol et" ve çıkış akışı, fixture-verify.js: bozuk ve temiz canlı site, urllist-test.js: eski adres listesi, redirects-test.js: eski yönlendirme (v0.12.2, test sitesi `startRedirectSites`), render-test.js: JavaScript render (v0.13.0, A bölümü tarayıcısız, B bölümü Chromium ister); JS sayfaları `fixture-rules.js` içinde (`/js` ve `JS_PAGES`); report-test.js: paylaşılabilir rapor ve `.env` (v0.14.0, zararlı site test içinde))
```

## Kurallar ve konvansiyonlar

1. Yeni kural `src/rules/definitions.js` içine yazılır. Her kuralda: id, category, severity (critical/warning/notice), team (SEO/İçerik/Frontend/Backend), title, description, fix, run.
2. Her yeni kural için `test/fixture-rules.js` içine onu tetikleyen bir sayfa ve `test/rules-test.js` içine beklenti eklenir. `/temiz` sayfasında hiçbir kural tetiklenmemeli.
3. Eşikler koda yazılmaz, `config/rules.json` içine yazılır.
4. Arayüz ve kural metinleri Türkçe, kısa cümleli, aktif fiilli (Simplified Technical English prensipleri).
5. Taranan sitelerden gelen her metin arayüzde `esc()` ile basılır (XSS).
6. Yeni bağımlılık eklemeden önce gerekçesi yazılır ve onay alınır.
7. API anahtarları sadece `.env` dosyasında durur. Sohbete veya repoya yazılmaz.
8. Her değişiklikten sonra `npm test` çalışır ve geçer.

## Durum

| Aşama | İçerik | Durum |
|---|---|---|
| Faz 1 | Crawler, CLI, Excel, web arayüzü, canlı durum şeridi | Tamam (v0.2) |
| Sprint 1 | Kural motoru (77 kural), Sorunlar sekmesi, sağlık skoru, başlık ağacı | Tamam (v0.3) |
| Altyapı | CLAUDE.md, .env.example, GitHub deposu `seo-audit` (Public), Claude depoyu klonlar | Tamam (v0.4.3) |
| Sprint 2 | Ek kontroller (11 kural): site sürümleri, SSL, HSTS, sıkıştırma, llms.txt, dış link, görsel; site kartı | Tamam (v0.4.0) |
| Arayüz | Koyu tema, landing giriş ekranı, bütün ekranlar yenilendi | Tamam (v0.4.1) |
| Yayın | Render (ücretsiz), SSRF koruması, yayın limitleri. Şifre isteğe bağlı, Render şifresiz (v0.8.4) | Tamam (v0.5.0) |
| Sprint 3 | Migration: Parça 1 karşılaştırma ekranı tamam (v0.6.0), yol kuralları + çoklu hedef + desen önerisi + açıklama (v0.6.1), taşıma projesi + 301 kontrolü (v0.7.0), eşleştirme ekranı düzeltmesi (v0.7.1), Parça 2 301 haritası (v0.8.0), gerçek site düzeltmeleri: dil kontrolü, bölüm uyarısı, ana sayfa, Excel kaynağı (v0.8.1), yapılacaklar listesi (yere göre), site hazırlık uyarısı ve kavram açıklamaları (v0.9.0), canlı adres ve staging adresi ayrımı (v0.9.1), Parça 3a canlıya çıkış listesi ve "Yeni yapı" seçeneklerinin birleşmesi (v0.10.0), Parça 3b canlı doğrulama (v0.11.0). Kod tamam. Sırada: gerçek sitede deneme (canlıya çıkmış bir proje) | Kod tamam (v0.11.0), gerçek site denemesi bekliyor |
| Eski adres listesi | v0.12.0: Search Console, Analytics, backlink CSV veya düz liste. Taramada olmayan adresler eski sitede istenir, açılan sayfa eski sayfa olur. 301 haritası trafiğe göre sıralı, Excel'de trafik sütunları ve liste sayfası. v0.12.1: Yapılacaklar, Canlıya çıkış ("Karar bekleyen") ve Canlı doğrulama trafiğe göre sıralı, Excel'de trafik sütunları; eski sitede istenmeyen adres (karar 7b) içeriksiz eski sayfa olur ve canlıda kontrol edilir. v0.12.2: eski sitede yönlenen adres (liste ve taramadaki link) 301 haritasına girer: son hedefin yeni adresine tek adım, hedefin kararını izler | Kod tamam (v0.12.2), gerçek dışa aktarım ile deneme bekliyor |
| Landing | Portfolyo için statik tanıtım sayfası (kadastro paftası tasarımı), GitHub Pages veya Netlify | Tamam (v0.8.3), yayın bekliyor |
| Bakım | Kod incelemesi ve hata düzeltme sürümü: 12 hata (şifre sızıntısı, gövde zaman aşımı ve boyutu, Host/Origin kontrolü, SVG title, noindex okuma, bozuk URL, kelime sayısı, 301 kontrol önbelleği, istek sınırı, sitemap entity, tarama kimliği) | Tamam (v0.10.1) |
| Doğrulama | Aracın taramasını Screaming Frog dışa aktarımı ile karşılaştıran komut (`npm run dogrula`). Plan kullanıcı ile yapıldı. Sırada: kullanıcı iki projede taramaları yapar ve özet dosyalarını sohbete yükler | Araç tamam (v0.10.2), ölçüm bekliyor |
| Belge | README baştan yazıldı: aracın ne yaptığı, ne yapmadığı ve güncel yol haritası | Tamam (v0.10.4) |
| Sprint 4 | AI özellikleri. Ön görüşme yapıldı (v0.8.1): fiyat, maliyet hesabı, anahtar ve ücret sahipliği konuşuldu. Sprint 3 bitmeden başlamaz. Başlamadan önce tekrar konuşulur | Bekliyor (Claude API anahtarı gerekir) |
| Sprint 5 | Entegrasyonlar | Bekliyor (PSI anahtarı, GSC OAuth, ClickUp token) |
| Paylaşılabilir rapor | v0.14.0: tek HTML dosyası (site denetimi ve taşıma projesi), müşteri ve ekip kitlesi, ekip çevirisi (CMS → Backend, Siz → SEO), script yok, sunucuda kalmaz. Ayrıca `.env` okuma düzeltmesi | Kod tamam (v0.14.0), gerçek projede deneme bekliyor |
| ClickUp | v0.14.1: tasarım onaylı (Karar günlüğü v0.14.0, C1–C16), Free plan sınırı | Sırada |
| Sprint 6 | JS render (v0.13.0): isteğe bağlı Playwright modu, ham ↔ render farkı, sadece JS ile gelen linkler, 9 JavaScript kuralı, Excel "JavaScript farkı", proje sitesi başına mod. v0.10.2 sırasında 4. iş idi | Kod tamam (v0.13.0), gerçek site denemesi bekliyor |

Testler (v0.14.0, 15 dosya, 358 kontrol Chromium ile; Chromium yoksa 22 kontrol atlanır): rapor 14, crawler 22, kural 117 (Chromium yoksa 105), yayın modu 12, karşılaştırma 49, 301 haritası 17, yapılacaklar 8, proje 20, canlıya çıkış 11, sunucu 8 (IPv6 varsa 9), doğrulama 8, canlı doğrulama 12, eski adres listesi 30, eski yönlendirme 13, JavaScript render 17 (Chromium yoksa 7) kontrol (toplam yaklaşık 45 sn; render testleri yaklaşık 25 sn). 3.000 × 3.000 sayfa öneri hesabı yaklaşık 1,5 sn. 5.000 sayfa denetimi yaklaşık 1 sn.

Gerçek site denemesi (v0.7.0, Şamil Şahin taşıması, 11 Ekim 2026). Eşleştirme ekranı: `/` 7 sayfa (3 bulundu), `/tr/` 46 sayfa, `/fr/` 19 sayfa, `/prosedur/` 13 sayfa. Bulgular:
- Araç sadece yol ile arar. Slug değişince sayfayı bulamaz ve "Bölüm kaldırıldı" önerir. "Bulunamadı" ile "kaldırıldı" aynı şey değildir. Bu öneri yanlış güven verir. `/prosedur/` bu durumda.
- `/tr/` için "Bölüm kaldırıldı" kayıtlı kural olarak seçili. Türkçe sayfalar kaldırılmadı, ayrı alan adına taşındı. Büyük olasılıkla Türkçe sitede de slug değişti, bu yüzden "Türkçe · /tr/ kalkar" seçeneği az sayfa buldu. Kullanıcıya soruldu (v0.7.1), cevap bekleniyor: Türkçe sitede adresler eski `/tr/` adresleri ile aynı mı (önek hariç), yoksa slug da değişti mi? v0.7.1 ile `/tr/` satırı açılır ve cevap sayfa listesinde görünür. Kayıtlı "Bölüm kaldırıldı" kararını kullanıcı Türkçe site olarak değiştirmeli.
- Listedeki sayı (2 / 7) sadece taramaya bakar. Sonuçtaki sayı (3 / 7) istekten sonra gelir. Fark açıklanmıyor.
- "Diğer sayfalar" etiketi belirsiz. Bölüm satırı açılmıyor: hangi sayfanın bulunduğu görünmüyor.

v0.7.1 planı (gerçek site denemesinden sonra güncellendi). 1-4 tamam (v0.7.1). Sıra:
1. Hiçbir seçenek sayfa bulmazsa "Bölüm kaldırıldı" önerme. Satır "Bulunamadı: adresler değişmiş olabilir" der. Seçim olarak hedef siteler ve "Bölüm kaldırıldı" kalır. Sıradaki iş kartı nedeni açıklar.
2. Bölüm satırı açılır: eski sayfa → bulunan yeni adres veya "bulunamadı".
3. Sayılar tek ve açık etiket alır ("taramada bulundu" ile "kontrol sonrası bulundu" ayrımı ya da tek sayı).
4. "Diğer sayfalar" yerine açık ad (örnek: "Kök ve küçük bölümler").
5. Sonra asıl v0.7.1 işi: işin yapıldığı yere göre yapılacaklar listesi ve kavram açıklamaları.
Öncelik kararı (11 Ekim 2026, kullanıcı onayladı): Çok alan adlı taşıma nadirdir. Yaygın iş tek eski site → tek yeni sitedir. İki durumda da asıl zorluk slug değişimidir. Gerçek projede SEO ajansı 301 listesi göndermedi: listeyi araç üretmeli. 301 kontrolü ancak 301'ler kurulduktan sonra işe yarar. Yeni sıra:
1. v0.7.1: Eşleştirme ekranı düzeltmesi (yukarıdaki plan 1-4). Tamam.
2. v0.8.0: Parça 2, 301 haritası önerisi. Tamam (v0.8.0).
3. Sonra: işin yapıldığı yere göre yapılacaklar listesi ve kavram açıklamaları.
Gerçek site denemesi (v0.8.0, 11 Ekim 2026, çok dilli taşıma: İngilizce kökte, Türkçe /tr/ altında, Fransızca /fr/ altında; yeni İngilizce site eski alan adında, Türkçe site ayrı alan adında). Bulgular:
- /tr/ bölüm kararı yanlışlıkla geçecek site (İngilizce) olarak kaydedildi (taramada 0 sayfa). Bölüm kararı aramayı o siteye sınırladığı için Türkçe sayfalar İngilizce sayfa önerisi aldı. Araç bu kararı uyarmadı.
- Fransızca bölüm kaldırıldı. Arama serbest kaldı ve Fransızca sayfalar Türkçe siteye eşleşti.
- Ana sayfa hiç aday değildi. Eski bölüm ana sayfaları (/tr/home, /fr/page-daccueil) yanlış sayfaya gitti.
- Excel onaylanan satırda güven, puan ve nedeni silmişti. Önerinin doğruluğu ölçülemedi.
- Bölüm kuralı doğru olan eski İngilizce /prosedur/ sayfaları çoğunlukla doğru eşleşti. Dolgu sayfaları genel /procedures sayfasına gitti (daha özel sayfa vardı); kaynağı belli değil.
v0.8.1 bu dört sorunu düzeltti. Tekrar test bekliyor.

Açık noktalar (v0.14.0):
- Gerçek projede denenmedi. Şamil Şahin veya Doyuyo projesinde "Rapor indir" ile iki kitleyi indirin. Kontrol edin: özet cümlesi doğru mu, ekip kartları anlaşılır mı, liste uzunluğu yeterli mi (`report.listLimit`), sağlık skoru notu doğru mu.
- Taşıma projesinde "Açık iş" sayısı iki türü toplar: Yapılacaklar işi adres başınadır (ekranla aynı), Canlıya çıkış ve Canlı doğrulama işi satır başınadır (ekranla aynı). Bir "Staging Google'a açık · 14 sayfa" satırı 1 iştir.
- Çıkıştan sonra rapor sadece Canlı doğrulama işlerini gösterir. Çıkış öncesi iş listesi raporda yok, Excel'de var (not yazar). "Korunan sayfa" çıkış öncesi karşılaştırmadan gelir.
- Logo yok (karar R6). Müşteri adı metindir.
- `<details>` kapalı liste bazı tarayıcılarda kapalı yazdırılır. Yazdırma stili `::details-content` kullanır (Chrome 131+). Diğer tarayıcıda listeleri elle açın.
- Raporun yazı tipi sistem yazı tipidir (dış istek yok, CSP `default-src 'none'`).
- `.env` artık okunur. Kök `.env` içindeki değerler testlerin başlattığı sunucuya da girer (testler PORT, HOST, CRAWL_DIR, PUBLIC_MODE, APP_USER, APP_PASS değerlerini açıkça verir; deney: yayın modu, şifre ve ALLOWED_HOSTS yazılı `.env` ile sunucu, liste, koruma ve render testleri geçti). `RULES_FILE` gibi bir değer kök `.env` içinde olursa testler bozulur (deney). `.env` içine sadece `.env.example` değişkenlerini yazın.
- Ekran kontrolünde bulunan eski sorun düzeldi: proje başlığı kelime ortasından bölünüyordu (`.title` → `overflow-wrap: anywhere`).

Açık noktalar (v0.13.0):
- Gerçek sitede denenmedi. Claude'un ortamı internete çıkmaz: süre, bellek ve yanlış alarm sadece yerel test sitelerinde ölçüldü (sayfa 0,6–1,3 sn; 1 sayfa yaklaşık 160 MB, 4 sayfa yaklaşık 206 MB PSS, headless shell). İlk denemede bir React/Next sitesini ham ve render ile tarayın. Karşılaştırın: sayfa sayısı, süre, JavaScript kuralları, engellenen dış alan adları (Excel "JavaScript farkı").
- Site JS paketini başka alan adından (CDN) yüklüyorsa render boş kalır ve "Sayfa render edilemedi" veya "İçerik sadece JS" çıkmaz: içerik hiç oluşmaz. Excel'de "Engellenen alan adları" sütununa bakın ve alan adını izin listesine yazın. İleride: render boş ve dış istek engellenmişse araç bunu ayrıca söyleyebilir.
- `render.blockHosts` içinde `google.com` var (reCAPTCHA, harita). Google'ın kendi alt alan adını kullanan bir site (örnek: `sites.google.com`) taranırsa sorun olabilir: taranan site her zaman izinlidir, ama başka bir google.com alt alan adı engellenir.
- Bekleme "ağ 500 ms sessiz" kuralıdır. JS içeriği 500 ms'den uzun bir zamanlayıcı ile isterse (setTimeout 1 sn) araç içeriği kaçırır. Test sırasında bu yarış görüldü (quietMs 300, zamanlayıcı 300). Yanlış boş sonuç görülürse `render.quietMs` artırın.
- Kullanıcı etkileşimi yok (tıklama, kaydırma). Kaydırınca yüklenen içerik ve linkler görünmez. Google da kaydırmaz, ama yüksek bir pencere kullanır. Pencere boyutu varsayılan (1280 × 720), mobil değil.
- JS ile değişen adres (`location.href`) sadece sayfa kaydına yazılır (`render.jsUrl`, ayrıntıda görünür). Kural yok.
- POST istekleri aynı sitede izinli (GraphQL ve veri istekleri için). Staging'de sayfa açılınca POST atan JS çalışır.
- Kurulu Chrome (`CHROMIUM_PATH`) denenmedi. Playwright sürümü ile uyumsuz olabilir. Önerilen yol `npx playwright-core install chromium-headless-shell`.
- GitHub Actions'ta Chromium yok: 22 kontrol atlanır, kalan testler çalışır. Render kodundaki bir hata Actions'ı kırmızı yapmaz. Claude teslimden önce render testlerini kendi ortamında çalıştırır. İş akışına tarayıcı kurulumu eklemek kullanıcının kararıdır (elle).
- `js-shell-suspect` ve render mod notu `meta.json` içindeki değerden okunur. Kayıt v0.13.0 öncesi ise not çıkmaz (tekrar tarayın). Kural `rules.json` değişince tekrar çalışsa da `meta.json` içindeki `jsShell` değeri tarama anındaki değerdir.
- Ayrıştırıcı düzeltmesi: `absHosts.asset` artık `<script src>` hostlarını da okur (önceden okumuyordu). Canlıya çıkış listesi ve canlı doğrulama, script içindeki staging adresini yeni bulur. Bu yeni iş eski taramada görünmez: siteyi tekrar tarayın.
- Proje dosyasında site `render` alanı sadece `true` iken saklanır. "Projeyi indir" bu ayarı ve izin listesini taşır.

Açık noktalar (v0.12.2):
- Gerçek sitede denenmedi. Eski sitede yönlendirmesi çok olan bir projede 301 haritasının "Eski yönlendirme" sekmesini açın. Satır sayısı büyükse (eski sitede çok sayıda yönlendirme) liste kalabalık olabilir: bu satırlar karar istemez, sadece CSV'ye girer.
- Zincirin ara adımı (`/eski-zincir → /ara → /urun` içinde `/ara`) satır almaz. Kendi kaydı (link veya liste) varsa alır.
- Staging durumu sadece staging taraması bu adresi yönlendirme olarak bulduysa görünür (yeni staging isteği yok). Bu yüzden Yapılacaklar staging'de zaten kurulu bir 301'i "301 kurun" olarak gösterebilir. Canlı doğrulama gerçek durumu yazar.
- Normal tarama (link modu) başka alan adına giden yönlendirmenin hedefini de ister (liste modu istemez). Eski davranış, değişmedi. Satır hedef olarak ilk dış adımı kullanır, dış sitenin cevabını kullanmaz.
- Liste ekranı, eski taramada link ile bulunan yönlendirme için "Taramada vardı" yazar (yönlendirme olduğunu söylemez). Satır yine 301 haritasındadır.
- Sıradaki iş kartı ve harita metni "N sayfa için öneri" der. Dış adres ve eski hedefi eski sayfa olmayan yönlendirme de bu sayıya girer (sayfa değil, adres).
- Onaylı dış adres canlıda sadece Location ile karşılaştırılır (`ok-left`). Dış sayfanın açıldığı kontrol edilmez.

Açık noktalar (v0.12.1):
- Gerçek sitede denenmedi. Canlıya çıkmış bir projede listeyi ekleyin. Canlı doğrulamada "Eski sitede var mıydı bilinmiyor" ve "Kayıp sayfa · haritada karar yok" satırlarını kontrol edin. Kanıt eşiği `rules.json` → `urlList.lateProof` (her ölçü 1). Analytics 404 sayfasındaki görüntülemeyi de sayar: Analytics satırı zayıf kanıttır. Yanlış alarm sık olursa `views` değerini yükseltin veya null yapın.
- Geç sayfanın dili yok (`html lang` yok). 301 önerisinde dil filtresi çalışmaz: Türkçe adres İngilizce sayfa önerisi alabilir. Sonraki adım: yol önekinden dil tahmini (`/tr/`).
- Geç sayfa "durum 200" ile eski sayfa kümesine girer (adımlar sadece 200 HTML sayfayı eski sayfa sayar). Hiçbir ekran ve Excel sayfası bu sayfa için "200 verdi" yazmaz. Yeni bir adım eski sayfanın durumunu yazacaksa `late` işaretini kontrol etmeli.
- Geç sayfa staging'de yönleniyorsa (staging taramasında yönlenen yol) eşleştirme bu yönlendirmeyi kullanır. Bu bilgi taramadan gelir, istek değildir.
- Liste taraması silinirse (dosya yok) çıkıştan sonra liste adresleri geç adres olur: araç onları eski sitede bulunmuş sayfa olarak değil, içeriksiz sayfa olarak kullanır. Kabul edildi.
- Yapılacaklar: "hazır değil" sitenin bekleyen iş listesi birden çok yeri karıştırır. Sunucu sırası yere göredir. Arayüz bu listeyi ayrıca trafiğe göre sıralar. Excel'de bu işler kendi yerinde ve "Bekliyor" durumunda görünür.

Açık noktalar (v0.12.0):
- Gerçek dışa aktarım ile denenmedi. Sütun adları (`rules.json` → `urlList.columns`) Claude'un bilgisinden yazıldı. İlk denemede Search Console (Türkçe ve İngilizce arayüz), GA4 ve backlink dosyasını yükleyin. Araç sütun bulamazsa ekranda seçim ister: o adı listeye ekleyin.
- Search Console arayüzü zip dosyası verir. Araç zip açmaz (yeni bağımlılık gerekir). Kullanıcı zip içindeki `Pages.csv` dosyasını seçer.
- (v0.12.1 ile yapıldı) Yapılacaklar ve Canlı doğrulama trafiğe göre sıralı, çıkıştan sonra eklenen adresler canlı doğrulamada.
- (v0.12.2 ile yapıldı) Eski sitede yönlenen adres (`/indirim → /kampanya`) haritaya girmez (karar 5). Canlıdan sonra eski sunucu kuralları kaybolursa bu adres 404 verir. Sonraki adım: son hedefin yeni adresine 301 önerisi.
- Yayın modu sınırı (`yayin.maxUrls`) birim testte denendi (`toFetch`). Yayın modunda tam akış denenmedi: test siteleri 127.0.0.1 üzerinde, SSRF koruması bunları engeller.
- Liste taraması eski site taraması gibi ham sayfa verisi tutar. Kenar çubuğunda görünmez (proje kimlikleri arasında). Proje silinirse "Taramalar" altında görünür.
- "Tekrar isteyin" düğmesi taramada olmayan bütün adresleri tekrar ister (sadece yenileri değil). Küçük maliyet, kabul edildi.
- Eski küçük stil sorunu (değişmedi): mobilde proje başlığı kelimenin ortasından bölünür.

Açık noktalar (v0.11.0):
- Canlı doğrulama gerçek sitede denenmedi. Canlıya çıkmış bir projede "Canlıya çıktık" ile işaretleyin, her siteyi canlıda tarayın. Kritik listede yanlış alarm arayın. Özellikle "Aynı adreste açılıyor" (200 beklenen) satırlarına bakın: canlı site sondaki `/` için yönlendirme yapıyorsa bu satırlar "Sayfa yönleniyor" olur.
- Eski projeler: çıkış işareti yoksa adım sadece işaret formunu gösterir. v0.10.0 öncesi eski site taramasında etiket verisi yoktur ve çıkıştan sonra eski site tekrar taranamaz: araç "Etiket kontrolü yapılamadı" der (Kontrol edilemedi).
- Çıkıştan sonra Eşleştirme, 301 haritası, Yapılacaklar ve Canlıya çıkış adımları staging'e istek atmaya devam eder. Staging kapanırsa bu adımlar "Kontrol edilemedi" gösterir. Canlı doğrulama bundan etkilenmez (istek atmayan beklenen liste). İleride: çıkıştan sonra bu adımlar da istek atmaz.
- Çıkıştan önce taranmamış ek site: beklenen listede o sitenin sayfaları "Karar yok" olur (kural hedefi taranmadı). Site kartı yine görünür ve canlıda taranabilir.
- Canlı tarama robots.txt kurallarına uyar. Canlıda `Disallow: /` kalmışsa tarama sayfaları okuyamaz: araç Disallow'u kritik yazar, noindex ve staging adresi o taramada görünmez. Satırı kaldırınca tekrar tarayın.
- "Geçiş yapılmadı" uyarısı oran ile çalışır (`verify.notSwitchedRatio` 0.8, en az 3 adres). Eski site ve yeni site aynı yolları kullanıyorsa (301 az) uyarı çıkmayabilir.
- Ekran görüntüsü Claude'un ortamında Playwright ile alındı (projeye bağımlılık değildir). Ortam internete çıkmaz: Google Fonts isteği konsolda hata verir, uygulama hatası değildir.
- Eski küçük stil sorunu (bu sürümde değişmedi): mobilde proje başlığı kelimenin ortasından bölünür ("yeni / leme").

Açık noktalar (v0.10.1):
- v0.10.1 gerçek sitede denenmedi. Şifreli bir staging taraması yapın ve sonucu kontrol edin. Eşleştirmede "Tekrar kontrol et" düğmesini 301 kurduktan sonra deneyin.
- Kelime sayısı ve içerik parmak izi değişti (bitişik etiketler artık ayrı kelime). v0.10.1 öncesi tarama ile yeni tarama arasında "benzer içerik" ve 301 haritasının içerik puanı tutarsız olabilir. Bir projede bütün siteleri tekrar tarayın.
- `AUDIT_VERSION` 3 oldu. Eski taramalar açılınca denetim kendiliğinden tekrar çalışır (kural sonuçları değişebilir: noindex, title, URL kuralları). Eski taramadaki `title`, `titleCount` ve kelime sayısı tarama anındaki değerdir, tekrar tarama ile düzelir.
- Arayüzdeki "noindex" filtresi (`app.js` BUCKETS) hâlâ basit metin araması yapar. "bingbot: noindex" başlıklı sayfa filtrede görünür ama kurallarda noindex sayılmaz.
- IPv6 tarama kimliği testi sadece IPv6 olan bilgisayarda çalışır. Claude'un ortamında IPv6 yok: kimlik elle denendi (`ipv6-1_<tarih>`), tam test atlandı.
- Host kontrolü sadece yerel modda çalışır. Yayın modunda (Render) alan adı bilinmez ve veri zaten herkese açıktır. Origin kontrolü her modda çalışır. Sunucu bir ters vekil (reverse proxy) arkasında ise ve vekil Host başlığını değiştiriyorsa `ALLOWED_HOSTS` yazın.
- `npm audit` 3 orta açık gösterir: `fast-xml-parser` XMLBuilder (araç kullanmaz, düzeltme 5.x ana sürümünde) ve `exceljs` içindeki `uuid`. Kritik ve yüksek açık yok.
- İncelemede görülen, düzeltilmeyen küçük eksikler: `.xml.gz` sitemap okunmaz, 5 MB üstü sitemap kesilir, HTTP başlığındaki canonical okunmaz, `charset="utf-8"` (tırnaklı) başlığı doğru çözülmez (utf-8'e düşer).
- (v0.12.0 ile yapıldı) Öneri: "Eski URL listesi". Eski siteye CSV veya yapıştırılan adres listesi (Search Console, Analytics, backlink dışa aktarımı; isteğe bağlı tıklama sütunu). Araç adresleri eski sitede ister, 200 verenleri eski sayfa kümesine ekler, 301 haritasını tıklamaya göre sıralar. Neden: araç eski sayfaları sadece link ve sitemap ile bulur; linksiz ama trafik alan sayfa haritaya girmez. v0.9.1 kararı ile çelişmez (o karar hazır 301 listesi içe aktarmayı reddetti). Yol haritasında yok; sıra kullanıcı kararı (Parça 3b'den önce veya sonra).

Açık noktalar (v0.10.0):
- Canlıya çıkış listesi gerçek sitede denenmedi. Şamil Şahin veya Doyuyo projesinde siteleri tekrar tarayın (eski taramalarda yeni veri yok, liste "Tarama eski" der). Sonra Canlıya çıkış adımını açın. Kritik satırların listesini açın ve yanlış alarm arayın.
- Etiket kimliği sadece script ve noscript içinden okunur (GTM-, G-, UA-, AW-). Etiket sadece JS ile yüklenirse (örnek: consent aracı içinden) araç bulamaz ve "Eksik" der. Sprint 6 (JS render) bunu çözer.
- Staging adresi tahmini: projedeki yeni sitelerin tarama alan adı (canlı alan adından farklıysa) ve `stagingHosts` deseni. Başka bir geliştirme ortamı (adı tanıdık olmayan) bulunmaz.
- Canlı alan adında taranan site staging sayılmaz. Bu sitenin kontrolleri Parça 3b'de (canlı doğrulama) gelir. Ekran bunu not olarak yazar.
- Sitemap'teki staging URL sayısı adres sayısına eklenir (örnek: "9 adres" içinde 3 sitemap URL'si). Sayı bu yüzden sayfa sayısı değildir.

Açık noktalar (v0.9.0):
- Yapılacaklar listesi gerçek sitede denenmedi. Şamil Şahin projesinde Yapılacaklar adımını açın. Sayıları 301 haritası ve Excel ile karşılaştırın. Türkçe site az sayfalı ise uyarı görünmeli.
- Hazırlık eşiği `rules.json` → `todo` (oran 0.3, en az 10 eski sayfa). Sayfaları birleştiren gerçek bir küçük site de uyarı alabilir. Bu durumda kullanıcı uyarıyı kapatır. Yanlış alarm sık olursa oranı düşürün.
- Hazırlık kabulü projede `readyOk` alanında durur (site anahtarı → tarama kimliği). "Projeyi indir" bu alanı taşımaz.
- Karar bekleyen sayısı 301 haritasının sayısından küçük olabilir: hedefi olmayan sayfa (kural hedefi yok) Yapılacaklar'da sitenin "Sayfa oluşturun" işidir, haritada ise karar bekler. Kullanıcı haritada başka sayfa seçerse iş sunucunun 301 listesine geçer.
- Sunucu kuralı biçimleri (.htaccess, nginx, Shopify CSV) hâlâ yok. CSV tek biçimdir.

Açık noktalar (v0.8.4):
- Render şifresiz. Herkes tarama başlatabilir: aynı anda 1 tarama sınırı sizi bekletebilir. Kötüye kullanım görülürse Render → Environment bölümüne APP_USER ve APP_PASS eklemek yeterli (kod değişikliği gerekmez).
- Silme düğmeleri şifresiz çalışır. Gerekirse sonraki sürüm: yayın modunda silmeyi kapatmak veya şifresiz demo modu.

Açık noktalar (v0.8.1):
- v0.8.1 gerçek sitede denenmedi. Aynı projede /tr/ satırında uyarı görünmeli. "Bu seçimi kullan" ile Türkçe siteyi seçin. Ek site için canlı alan adını yazın. Sonra haritayı açın ve Excel'deki "Kaynak" ve "Araç önerisi" sütunları ile önerileri ölçün.
- Dil filtresi `html lang` değerine güvenir. Yeni site bu değeri yanlış yazarsa (Türkçe sitede `lang="en"`) filtre yanlış siteye sınırlar. Testte bunu kontrol edin. Gerekirse sonraki adım: sayfa metninden dil tahmini veya site ayarı ile dil seçimi.
- Eski sitede `hreflang` varsa dil eşleri doğrudan bulunabilir (AI gerekmez). Kullanıcıya soruldu, cevap bekleniyor.
- Gerekçede bölüm kelimesi bazen görünür ("Slug ortak: prosedur, botoks"): bölüm kelimesi sadece ilk yol parçası sayılır (/tr/prosedur/ içinde `tr`). Küçük kozmetik hata.
- Render'da aynı anda 1 tarama çalışır (`rules.json` → `yayin`). İkinci tarama hata verir. Sıra (kuyruk) özelliği gerekirse sonra küçük bir sürüm olarak yapılır. Şimdilik değişiklik yok.

Açık noktalar (v0.8.0):
- 301 haritası gerçek sitede denenmedi. Şamil Şahin projesinde haritayı açın. Önerilerin doğruluğunu ve güven etiketlerini kontrol edin. Eşikler `rules.json` → `redirectMap` (high 80, mid 55, low 35).
- Farklı dilde eş anlam bulunmaz (göz kapağı ↔ blepharoplasty). Sadece aynı kelime, ortak önek ve yakın yazım (prosedur ↔ procedures) bulunur. İçerik benzerliği (simhash) sadece 50 kelimeden uzun sayfada vardır. Anlam benzerliği Sprint 4'te (AI) gelir.
- CSV biçimi: eski_url, yeni_url, durum (301/410), kaynak. Sunucu kuralı biçimleri (.htaccess, nginx, Shopify CSV) sonraki sürümde.
- Bir yeni sayfa birden çok eski sayfanın hedefi olabilir. Araç bunu uyarmaz.

Açık noktalar (v0.7.1):
- v0.7.1 gerçek sitede denenmedi. Şamil Şahin projesinde eşleştirmeyi tekrar açın. `/prosedur/` ve `/fr/` "Bulunamadı" demeli, "Bölüm kaldırıldı" önermemeli. Satırları açın ve sayfa listesini kontrol edin.
- Yapılacaklar adımı şimdilik grup görünümünü ("Bütün sayfalar") gösterir. İşin yapıldığı yere göre liste v0.8.0'dan sonra gelir. (v0.9.0 ile tamam.)
- İstekler staging şifresini göndermez. Şifreli geçecek sitede 301 kontrolü "Kontrol edilemedi" olur.
- Otomatik öneri kaydedilmez. Tarama değişirse öneri de değişebilir. Kullanıcı seçerse kural olur.

Açık noktalar (Sprint 2'den):
- Ek kontroller gerçek bir sitede denenmedi. İlk denemede süreyi ve yanlış alarmları ölç. Eşikler: `checks` ve `brokenIgnoreStatuses`.
- `srcset` ve CSS arka plan görselleri kontrol edilmez.
- Kural kodu değişince eski denetimleri yenilemek için `AUDIT_VERSION` artır (`src/rules/index.js`). `configHash` sadece `rules.json` değişikliğini görür.

## Yol haritası (kalan sprintler)

**v0.7.0 — Taşıma projesi (arayüz, Sprint 3 Parça 2'den önce):** Araç kullanıcıyı adım adım yönlendirir. Adım çubuğu: Proje → Tarama → Eşleştirme → Yapılacaklar → (sonra) 301 haritası → Canlıya çıkış → Canlı doğrulama. (Güncel sıra v0.8.0 ve v0.10.0 kararlarında.) Her ekranda tek bir "Sıradaki iş" kartı. Boş veya engelli her sonuç nedeni ve sıradaki işi söyler.
- Proje: ad + "Yeni yapı nasıl?" sorusu (aynı alan adı ve aynı yollar / aynı alan adı, değişen yollar / diller ayrı alan adlarına). Site rolleri: eski site, eski alan adına geçecek site, ek siteler. Etiket (eski/yeni) seçimi gerekmez.
- Tarama: her site için "Tara" düğmesi ve durum (bekliyor, taranıyor, tamam, silinmiş).
- Eşleştirme: eski bölüm tablosu (`/tr/ · 8 sayfa → [TR site] · 7 bulundu`), öneri satırda hazır. Serbest kural editörü "Gelişmiş" altında. v0.6.1 tarayıcı kuralları projeye aktarılır.
- Model düzeltmesi: taşınan sayfa için iki kontrol: hedef sayfa var mı, eski yol "eski alan adına geçecek site" üzerinde hedefe 301 veriyor mu. Sonuç: "Hedef hazır, 301 kurulu" / "Hedef hazır, 301 eksik" / "Hedef yok".
- Yapılacaklar: işin yapıldığı yere göre liste (eski alan adı sunucusu: yönlendirmeler; hedef site: eksik sayfalar; içerik: title/meta/H1). Mevcut gruplar ikinci görünüm.
- Terimler: "ana hedef" yerine "eski alan adına geçecek site". "Yoklama" kullanıcıya gösterilmez. Her kavramın yanında kısa "?" açıklaması.
- İş büyükse iki sürüme bölünür: v0.7.0 (model, proje, tarama, eşleştirme), v0.7.1 (yapılacaklar, açıklamalar).

**v0.7.0 onaylı ekran tasarımı** (sohbette tıklanabilir taslak ile onaylandı, örnek: Şamil Şahin taşıması):
- Proje başlığı: proje adı, altında özet ("3 site · 2 kural · son tarama bugün").
- Adım çubuğu: Proje, Tarama, Eşleştirme, Yapılacaklar tıklanır. 301 haritası, Canlıya çıkış, Canlı doğrulama kesik çizgili ve pasif ("Sonraki sürüm"). Mobilde çubuk yatay kayar.
- "Sıradaki iş" kartı: adım çubuğunun altında, mavi sol çizgi. Tek cümle durum + tek düğme. Örnekler: "Türkçe site taranmadı. Eşleştirme için gerekli." [Türkçe siteyi tara]; "/fr/ bölümü için karar gerekli." [Kararı seç]; "15 iş var. En çok iş eski alan adı sunucusunda." [Excel indir].
- Proje ekranı: "Yeni yapı nasıl?" üç seçim kartı (aynı alan adı ve aynı yollar / aynı alan adı, yollar değişiyor / diller ayrı alan adlarına). Siteler listesi: Eski site, Eski alan adına geçecek site (? açıklaması: "Canlıdan sonra eski alan adını bu site kullanır. Bütün 301'ler bu sitede kurulur."), Ek site (ad verilir, örnek "Türkçe"). Düğmeler: + Site ekle, Projeyi indir, Proje yükle.
- Tarama ekranı: her site bir satır: alan adı + rol, durum etiketi (Tamam · N sayfa / Taranıyor / Taranmadı / Silinmiş), düğme (Tara / Tekrar tara). Not: "Staging şifreli ise şifreyi tarama sırasında girin. Araç şifreyi saklamaz."
- Eşleştirme ekranı: sütunlar Eski bölüm · ok · Nereye gidiyor? · Sonuç. Satır: "/tr/ · 8 sayfa → [Türkçe site · /tr/ kalkar ▾] → 7 / 8 bulundu". Seçenekler: her site + yol biçimi (aynı yol / önek kalkar / önek değişir), Bölüm kaldırıldı, Karar verin. Öneri seçili gelir; bulunamayan bölüm "Karar verin" ve amber "Öneri: …" etiketi alır. Altta: "Gelişmiş: serbest kural yaz" (v0.6.1 kural editörü).
- Yapılacaklar ekranı: işin yapıldığı yere göre satırlar: "<eski alan adı> sunucusu" (yönlendirme sayısı), her ek site (eksik sayfa), İçerik (title/meta/H1), Karar bekleyen. Her satırda sayı etiketi ve "Listeyi aç". Eski grup görünümü (Aynı kaldı, Yönleniyor, Kayboldu…) "Bütün sayfalar" altında kalır.
- Durum etiketleri: yeşil = tamam/sorun yok, amber = iş veya karar gerekli, gri = taranmadı/bekliyor. Kırmızı sadece hata ve ana düğme için (v0.4.1 renk kuralı).
- Giriş ekranı: iki seçenek, "Site denetimi" (tek site, mevcut Sorunlar ekranı) ve "Taşıma projesi". Kenar çubuğu: önce projeler, sonra projeye bağlı olmayan taramalar.
- Mobil (390 px): bölüm tablosunun her satırı karta dönüşür; site satırlarında düğme alta iner.


**Sprint 3 — Migration:** iki taramayı karşılaştırma ekranı (eski = `eski` etiketli, yeni = `yeni` etiketli). Kaybolan URL'ler, title/meta/H1 kaybı, 301 haritası önerisi (önce slug/title benzerliği, Sprint 4'te AI), 301 haritasını CSV/Excel olarak dışa aktarma, canlıya çıkış kontrolü (noindex/Disallow kaldı mı, staging linki kaldı mı), canlıda 301 haritası doğrulama, iki tarama arası ilerleme.

**Sprint 4 — AI (Claude API):** title ve meta description yazma, görsel alt text yazma, başlık yapısı önerisi, schema önerisi, Türkçe yazım kontrolü, odak anahtar kelime uyumu, 301 eşleştirmede içerik benzerliği. Maliyet kontrolü: sayfa başına tek çağrı, toplu işlem, önizleme ve onay.

**Sprint 5 — Entegrasyon:** PageSpeed Insights API (Core Web Vitals), Google Search Console (trafik ile önceliklendirme, indeks durumu), sorun → ClickUp task (kuralın team alanına göre).

**Sprint 6 — JS render:** Playwright modu. Ham HTML ile render edilmiş HTML farkı, sadece JS ile gelen linkler. (v0.13.0 ile yapıldı.)

## Doğrulama planı (v0.10.2, kullanıcı ile yapıldı)

Amaç: aracın bulgularına güvenmek. Yeni özellikten önce yapılır (10 Kasım 2026 kararı; eski plan "bütün özellikler bittikten sonra" idi).

Yöntem:
1. Referans araç: Screaming Frog (kullanıcının lisansı var). Siteler: Şamil Şahin (eski site ve yeni site) ve Doyuyo.
2. Kullanıcı her siteyi iki araç ile tarar. Ayarlar aynı olmalı: aynı başlangıç adresi, robots.txt'ye uy, JavaScript render kapalı (Screaming Frog → Rendering: Text Only), alt alan adları kapalı. Araçta URL sınırı sitenin sayfa sayısından büyük olmalı.
3. Screaming Frog'da: Internal sekmesi → filtre "All" → Export → CSV (`internal_all.csv`).
4. Kullanıcı komutu çalıştırır: `npm run dogrula -- <tarama kimliği> <internal_all.csv>`. Komut iki dosya yazar (`crawls/` içinde, depoya girmez): `dogrulama-<host>.json` (özet, alan başına en fazla 25 örnek) ve `dogrulama-<host>.csv` (bütün farklar).
5. Kullanıcı özet dosyasını sohbete yükler. Claude her farkı inceler. Her fark üç sonuçtan birini alır: araç hatalı (kod düzelir, test eklenir), eşik yanlış (`rules.json`), fark beklenen (aşağıya not).
6. Sonuç bu bölüme yazılır: site, tarih, alan, fark sayısı, karar. Müşteri adresi ve içeriği buraya yazılmaz (depo herkese açık): sadece sayı ve genel neden.

Karşılaştırılan alanlar: durum kodu, yönlendirme hedefi, title, meta description, ilk H1, canonical, meta robots, indekslenebilirlik, kelime sayısı, iç link sayısı (benzersiz kaynak sayfa), derinlik, title piksel genişliği. Ayrıca: sadece aracın bulduğu ve sadece referansın bulduğu sayfalar.

Beklenen farklar (hata değildir, ilk ölçümde doğrulayın):
- Kelime sayısı: iki araç metni farklı sayar. Komut aracın iki sayısından (bütün gövde, ana içerik) referansa yakın olanı kullanır. Tolerans `rules.json` → `validate`.
- Title piksel genişliği: araç kaba tahmin yapar (`titlePx`). Fark büyükse harf genişlikleri kalibre edilir.
- Araç izleme parametrelerini (utm_, gclid…) URL'den siler. Referans silmez: bu adresler "sadece referans buldu" listesine girer.
- Araç dosya uzantılı adresleri (pdf, görsel, css, js) taramaz. Referansın HTML olmayan satırları sayılmaz.
- Robots.txt ile engelli sayfa karşılaştırılmaz.

Bilinen sınır: sütun adları Screaming Frog'un İngilizce arayüzüne göredir. Komut bulamadığı sütunları uyarı olarak yazar ve o alanı karşılaştırmaz. Sütun adı farklı ise `src/validate.js` → `COLUMNS` listesine eklenir. Sütun adları Claude'un bilgisinden yazıldı, gerçek bir dışa aktarım dosyası ile denenmedi: ilk çalıştırmada uyarı satırını kontrol edin.

Sonuçlar: henüz ölçüm yok.

## Karar günlüğü

- v0.14.0: Paylaşılabilir rapor ve ClickUp tasarımı (kullanıcı "onaylıyorum" dedi; tek değişiklik: ClickUp Free plan baz alınır). İş iki sürüme bölündü: v0.14.0 rapor, v0.14.1 ClickUp.
- v0.14.0: Önce deney. Bulgu: kod `.env` dosyasını hiç okumuyordu (`CHROMIUM_PATH=/yok/chrome` yazılı `.env` ile render "kullanılabilir" kaldı). README "cp .env.example .env" diyordu. Çözüm `src/env.js` (`process.loadEnvFile`, yeni bağımlılık yok). Deney: kabuktaki değer kalır, kabuktaki boş değer de kalır (testler `CLICKUP_TOKEN=''` ile anahtarı kapatabilir), dosya yoksa `ENOENT` yakalanır. Dosya yolu deponun kökü (çalışma klasörü değil). Bozuk dosya sunucuyu durdurmaz, mesaj değer yazmaz.
- v0.14.0: Rapor kararları (R1–R10). R1 tek dosya HTML, PDF tarayıcının yazdırma özelliği. R2 sunucu raporu diske yazmaz. R3 raporda script yok: `Content-Security-Policy` hem yanıt başlığında hem meta etikette (`default-src 'none'; style-src 'unsafe-inline'; img-src data:; base-uri 'none'; form-action 'none'`), listeler `<details>`. R4 sıra: özet cümle, 4 sayı, kritik işler, ekip başına işler, taşıma durumu (proje), adres listeleri, notlar. R5 iki kitle: müşteri (kural kimliği yok, 20 satır), ekip (kural kimliği, 50 satır); bilinmeyen kitle müşteri olur. R6 müşteri adı ve hazırlayan, logo yok. R7 ekip çevirisi `report.teams` (CMS → Backend, Siz → SEO): ekran etiketleri değişmez (v0.9.0 kararı korunur). R8 tek site denetiminde de rapor var. R9 yayın modunda açık. R10 eşikler `rules.json` → `report`.
- v0.14.0: Model. Site: kritik ve uyarı kuralları (`report.minSeverity`), birim = kural; bilgi notu sayısı not olur. Proje çıkıştan önce: Yapılacaklar (yer × iş türü, bekleyen iş hariç) + Canlıya çıkış (kritik, çıkış anında, kontrol; "Karar bekleyen" Yapılacaklar'daki karar işi ile aynı olduğu için girmez). Çıkıştan sonra: Canlı doğrulama (kritik, düzeltin, kontrol edilemedi; `live-running` hariç). Proje birimlerinde kural kimliği yok (ekran kontrolünde `yapilacaklar:decide|map` gibi iç anahtar anlamsız görüldü); her birimin sabit `key` alanı var (ClickUp defteri için).
- v0.14.0: Sağlık skoru (proje). Çıkıştan önce yeni sitenin staging taraması. Staging'de `robots-blocks-site` skoru 40 ile sınırlıyordu: rapor bu site kuralını saymaz (`report.stagingRules`, sadece site kuralı olabilir) ve not yazar. Başka kritik site kuralı varsa sınır kalır. Çıkıştan sonra canlı tarama varsa skor ondan gelir ("Sağlık skoru (canlı)").
- v0.14.0: Alt başlık. Geçecek site çıkışta eski alan adını alır: çıkıştan önce "eski → staging (staging)", sonra "eski · yeni site canlıda". Site adları raporda kısa: Eski site, Yeni site, ek site adı.
- v0.14.0: Proje alanı `report: { client, by }` (`validateProject`, `cleanReportInfo`: kontrol karakteri yok, en fazla `report.maxNameLength`). PUT alanı gönderirse değiştirir (boş da), göndermezse eski değer kalır (eski sekme). "Projeyi indir" ve "Proje yükle" taşır. Sorgu değeri (`musteri`, `hazirlayan`) o indirme için proje değerinden önce gelir ve projeyi değiştirmez. Arayüz adlar değişince önce projeyi kaydeder.
- v0.14.0: Arayüz. "Rapor indir" (gri) düğmesi: site sonuç başlığında Excel'in solunda, proje başlığında sağda. Panel: kitle seçimi (iki kart), iki ad, not, İndir ve Vazgeç. Dosya `fetch` ile gelir: hata (taranmamış proje) panelde yazılır, JSON sayfası açılmaz. Görünüm değişince panel kapanır. Ekran görüntüsü 1440 ve 390 px: site paneli, proje paneli, hata, dört rapor (proje müşteri, proje ekip, site, çıkış sonrası). Taşma yok. Konsol hatası sadece Google Fonts (ortam internete çıkmaz). Ekran kontrolünde düzelen rapor hataları: çıkıştan sonra "· 0" sayısı, boş sütun (artık gizli), proje kimlikleri, proje raporunda "Kural ID" notu.
- v0.14.0: Testler `test/report-test.js` (14 kontrol). XSS testi zararlı title'ı iki sayfaya koyar ("title-duplicate" ayrıntısı title'ı yazar), proje adını ve adresi de zararlı yapar; kontrol: script ve img etiketi yok, tırnaklı öznitelik dışında olay özniteliği yok, `javascript:` linki yok. Deney: `esc()` bozulunca 4 kontrol başarısız oldu. Eski kodda dosya modül hatası ile çöktü; sadece yeni modüller eklenince 5 API kontrolü başarısız oldu. `.env` testi `ENV_FILE` ile `ALLOWED_HOSTS` okur (render durumuna bağlı değil: Chromium olmayan yerde de çalışır). Eski testler aynen geçti. Yeni bağımlılık yok.
- v0.14.0: `package-lock.json`: `npm install` kök paket kaydından `playwright-core` satırını sildi (paket `optionalDependencies` içinde). Teslimde depodaki dosya korundu, sadece sürüm alanı değişti.
- v0.14.0 → v0.14.1 ClickUp tasarımı (onaylı, kod yok). C1 görev birimi iş türüdür, sayfa değil: denetimde kural × site, taşımada yer × iş türü ("301 kurun · 15 adres · eski.example sunucusu"), Canlıya çıkış ve Canlı doğrulamada satır × site (raporun birimleri ve `key` alanı). C2 kritik ve uyarı görev olur, bilgi olmaz (`clickup.minSeverity`). C3 öncelik: kritik → Urgent, uyarı → Normal. C4 metin: başlık iş + sayı + yer; açıklama Sorun, Çözüm, Etkilenen adresler (en fazla `clickup.maxUrls` 50), "Bütün liste Excel'de", gri satır kural kimliği; süre tahmini yok (kullanıcının ClickUp kuralı). C5 etiket: ekip (`backend`, `frontend`, `icerik`, `seo`), yer (`eski-sunucu`, `yeni-site`, `icerik`), `seo-audit`; eksik etiket önce alanda açılır (`POST /space/{id}/tag`; olmayan etiketin kendiliğinden açılıp açılmadığı doğrulanmadı). C6 projede ekip → ClickUp kişisi eşlemesi, isteğe bağlı. C7 liste seçici (çalışma alanı → alan → klasör → liste), seçim projede. C8 defter: `key` → görev kimliği ve adresi, projede (`crawls/`), tek site denetiminde `crawls/clickup/<host>.json`; "Projeyi indir" taşır. Bu v0.7.0 "projede sonuç yok" kuralından küçük farktır: defter tarama sonucu değil, dış sistemdeki görev kimliğidir. C9 istekten önce "gönderiliyor", sonra "açıldı"; hata olunca dur; zaman aşımında tekrar gönderimde listede aynı adlı görev aranır. C10 tek sıra, `clickup.minGapMs` 650 ms, 429 → `X-RateLimit-Reset` kadar bekle, gönderim başına en fazla `clickup.maxTasks` 50. Free plan: token başına dakikada 100 istek (kullanıcı kararı: Free baz alınır). C11 durum sadece okunur (liste başına 100 görevlik sayfa), kendiliğinden kapatma yok; araç düzeldi derse not. C12 mevcut görevi güncelleme yok; sayı değişince önizleme "Sayı değişti". C13 yayın modunda kapalı (Render şifresiz). C14 anahtar sadece `process.env.CLICKUP_TOKEN`; yanıt, rapor, Excel, log ve hata metnine girmez; test bütün yanıtlarda anahtarı arar. C15 sahte ClickUp sunucusu, adres `CLICKUP_API_BASE` (sadece ortam değişkeni), testte `CLICKUP_TOKEN` açıkça yazılır. C16 "ClickUp'a gönder" düğmesi "Rapor indir" yanında; panel: liste seçimi → önizleme tablosu (görev, ekip, sayı, durum: Yeni / Var · açık / Var · kapalı) → "N görevi aç". CSV eki ilk sürümde yok. API (belgeden, ortam erişemez): `POST /v2/list/{list_id}/task`, `markdown_content` description'dan önce gelir, `Authorization` ham token (Bearer yok).

- v0.13.0: JavaScript render (kullanıcı bağımlılığı ve D1–D12 tasarımını "onay" ile onayladı). Önce deney: bugünkü kod JS ile eklenen title, H1, canonical ve açıklamayı görmedi, JS linkini istemedi; JS sayfasında 5 yanlış alarm (`title-missing` kritik, `canonical-missing`, `desc-missing`, `h1-missing`, `thin-content`).
- v0.13.0: Bağımlılık `playwright-core` 1.63.0 (14 MB, alt paket yok, kurulumda indirme yapmaz), `optionalDependencies`, kesin sürüm (Chromium revizyonu sürüme bağlı; Claude'un ortamındaki Chromium revizyon 1243 bu sürüm ile aynı). Reddedilen: `playwright` (gereksiz test aracı), `puppeteer` (kurulumda Chrome indirir: Actions ve Docker şişer), `jsdom` (gerçek tarayıcı değil, JS Node içinde çalışır). Paket `import()` ile sadece render istenince yüklenir. Paket veya Chromium yoksa araç normal çalışır, seçenek pasif olur ve nedeni yazar (`/api/info` → `render`).
- v0.13.0: Ağ kuralı (deney ile). Düz Playwright iç ağ sunucusuna 13 yoldan istek attı (script, CSS, img, iframe, fetch, XHR, beacon, WebSocket, EventSource, prefetch, service worker, 302 ile script ve sayfa). Çözüm iki katman: (1) her istek `context.route` ile Node kontrol noktasına gelir ve crawler'ın `request()` fonksiyonu ile istenir (SSRF koruması, zaman aşımı, `maxBodyBytes`, şifre sadece taranan siteye); (2) tarayıcının kendi ağı ölü vekile gider (`proxy` + `<-loopback>`). Deney: Node'un verdiği 302 sonrası tarayıcı yönlendirmeyi kendisi izler ve kontrol noktasına uğramaz; bu yüzden yönlendirme Node'da adım adım izlenir ve tarayıcı sadece son cevabı alır (her adım host politikası, robots.txt ve korumadan geçer). WebSocket kapalı (`routeWebSocket`), service worker kapalı. Her sayfa yeni bağlam (çerez ve depolama yok).
- v0.13.0: Şifre. Playwright `httpCredentials` şifreyi 401 cevabından sonra başka hosta gönderdi (deney). Kullanılmaz. Şifreyi `headersFor()` ekler (v0.10.1 kuralı).
- v0.13.0: Host politikası. Taranan site (www aynı site) her zaman izinli. Sonra `render.blockHosts` (analytics, reklam, sosyal, font, consent) alt alan adlarında ve izin listesinde de kazanır. Sonra sitenin alt alan adları ve izin listesi (tarama ayarı, projede site başına `renderAllow`, en fazla 20). Diğer her şey engelli ve sayılır (`render.blockedHosts`). `render.blockTypes`: görsel, video, font hiç istenmez. Etiket kimliği DOM'daki script src'den okunur: GTM isteği gönderilmeden kimlik bulunur (test).
- v0.13.0: Ana belge. Tarayıcıya ham okumanın HTML'i UTF-8 olarak verilir (deney: karakter kodu başlığı olmayan sayfada tarayıcı Türkçe harfi bozdu). Sayfa ikinci kez istenmez (test). Önbellek: kontrol noktası açıkken tarayıcı önbelleği kapanır (deney: 3 sayfa = 3 kez aynı JS); JS ve CSS tarama boyunca bellekte tutulur (`render.cacheMb`).
- v0.13.0: Bekleme. `load` sonrası ağ `render.quietMs` (500) sessiz kalınca biter, en fazla `maxWaitMs` (8000), toplam `timeoutMs` (20000). Deney: `load` geç gelen fetch içeriğini kaçırdı. Sonsuz döngü JS: `goto` zaman aşımı, bağlam kapanır, tarayıcı sağlam kalır (deney).
- v0.13.0: Alan kaynağı (D5). Render'dan: title, description, canonical, başlıklar, linkler, kelime, içerik izi, görsel, JSON-LD, hreflang, OG, viewport, favicon. Ham: HTTP alanları ve `blockingCss/Js`. Birleşim: `metaRobots` (ham noindex render'da kaldırılsa da kalır), `tracking`, `gscVerify`, `absHosts`. Linkler: render linkleri (`js: true` ham HTML'de yoksa) + JS'nin kaldırdığı ham linkler. Ham özet `raw` alanında; render robots değeri `metaRobotsJs`. Render hatasında ham alanlar kalır (`rendered: false`).
- v0.13.0: Kurallar (D6), kategori `js`: `js-title-only`, `js-h1-only`, `js-content-only` (`rawContentRatio` 0.5, `contentMinWords` 50), `js-links-only` (`jsLinkRatio` 0.5, `jsLinkMin` 3), `js-meta-changed` (title iki tarafta doluysa; description, canonical, robots her farkta), `js-noindex-removed` (kritik), `render-failed` (sayfa ve tarayıcı açılmazsa site satırı), `render-resource-blocked` (aynı sitede robots.txt ile engelli JS/CSS/veri), `js-shell-suspect` (sadece ham tarama: sayfaların `shellRatio` oranı ve en az `shellMinPages` sayfa boş title/H1, en fazla `shellMaxWords` kelime ve script; veya başlangıç sayfası böyle ve ham HTML'de iç link yok). Son koşul ekran kontrolünde eklendi: JS sitesinin ham taraması tek sayfa buldu ve kural tetiklenmedi. Parser yeni alan `scripts` (çalışan script sayısı). `AUDIT_VERSION` 4.
- v0.13.0: Taşıma projesi (D7). Site tanımında `render` ve `renderAllow`. Proje taraması siteyi tanımdaki mod ile tarar. Eşleştirme ve 301 önerisi taramanın alanlarını kullanır (kod değişmedi). Yoklama ham kalır. Siteler farklı modda tarandıysa Tarama ve Eşleştirme adımı not gösterir. Ham taramada `js-shell-suspect` varsa Sıradaki iş kartı "Render ile tekrar tara" der: sadece Tarama adımında (sonraki adımları engellemez) ve render kullanılabilirken. Bilgi `meta.json` → `render`, `jsShell` üzerinden gelir.
- v0.13.0: Sınırlar (D8) `rules.json` → `render`. Taramada `render.limits` ile değişir (test). `maxPages` (1000) sonrası sayfa ham okunur ve `render.skipped: 'limit'` alır, `meta.render.limitReached`.
- v0.13.0: Yayın modu (D9): render kapalı (`/api/info`, POST 400). Docker `npm ci --omit=dev --omit=optional`: imaj değişmez. Neden: alpine üzerinde Playwright Chromium çalışmaz, 512 MB dar, açık sunucuda tarayıcı riski.
- v0.13.0: Çıkıştan sonra (D10): kilit render'dan önce kontrol edilir (409, eski siteye 0 istek, test). Liste taraması (`seeds`) ve canlı doğrulama render yapmaz. Canlı tarama sitenin mod ayarını kullanır.
- v0.13.0: Testler (D11). `test/render-test.js` (17 kontrol): A bölümü her yerde (birleşim, host politikası, liste modu, `CHROMIUM_PATH=/yok` ile ham devam, yayın modu, tarayıcı yokken 400, proje ayarı ve kilit), B bölümü Chromium ile (10 kontrol). Kural testi JS sayfalarını ayrı render taramasında dener (`/js`, `maxDepth` 2; `/temiz` render modunda temiz; Excel sayfası). Chromium yoksa toplam 22 kontrol "atlandı" yazar ve geçer (deney: `PLAYWRIGHT_BROWSERS_PATH` boş klasör). "İç ağ" sunucusu ikinci host adıdır (`localhost`): macOS `127.0.0.2` açmaz. Test için crawler `guard` seçeneği aldı. Eski kodda (v0.12.2 + sadece `render.js`) kural testi render bölümünde çöktü, render testinde 14/17 başarısız. Render testi 5 kez üst üste geçti.
- v0.13.0: Arayüz (D12): form kutusu, durum satırı, izin alanı; rapor başlığı ve uyarılar; sayfa ayrıntısında "Ham HTML ↔ Render" tablosu (değişen satır sarı); proje Tarama adımında site kutusu, etiketler, mod notu. Ekran kontrolünde bulundu: `chg` sınıfı mevcut stil ile çakıştı (`jd-chg` oldu); boş robots kırmızı görünüyordu. Ekran görüntüsü 1440 ve 390 px: form, Sorunlar, ayrıntı, proje Tarama (JS kabuğu ve render sonrası), Eşleştirme. Taşma ve konsol hatası yok.
- v0.13.0: Excel "JavaScript farkı" sayfası (sadece render taramasında) ve Özet satırı. CLI `--render`, `--render-allow`.
- v0.13.0: Bulunan eski hata (v0.10.0): parser `absHosts` listesini script'ler silindikten sonra okuyordu; `<script src="https://staging…">` hiç bulunmuyordu. Liste artık silmeden önce okunur. Canlıya çıkış testi aynen geçti.

- v0.12.2: Eski sitede yönlenen adres için 301 (kullanıcı tasarımı "onay" ile onayladı). Önce deney: bugünkü kodda liste taramasındaki yönlenen adres (`/eski-indirim`) ve eski taramada link ile bulunan yönlenen adres (`/eski-link`, zincir, kırık, dış adres) 301 haritasında yoktu, canlı doğrulama onları istemedi. Yönlendirme verisi taramada vardı (`redirectChain`, `finalUrl`, `finalStatus`).
- v0.12.2: Karar 5 (v0.12.0) değişti. Eski metin: "Eski sitede yönlenen adres haritaya girmez." Yeni: yönlenen adres haritaya girer, satır son hedefin yeni adresine tek adımda gider (zincir yok). v0.6.0 kuralı değişmez: yönlendirme eski sayfa sayılmaz. Eski sayfa sayısı, korunan oran ve karşılaştırma onu görmez ("Yönleniyor" satırı oluşmaz, çift satır yok).
- v0.12.2: Kapsam: liste adresleri ve eski taramada link ile bulunan yönlendirmeler (`oldRedirects`). Aynı yola yönlenen adres (http→https, www, sondaki `/`: `pathKey` aynı) satır almaz. Zincirin ara adımı satır almaz. Liste adresi sadece listede kaldıkça girer. Veri sadece çıkış öncesi taramalardan gelir: istek yok. Geç adresin (late) yönlendirme verisi yoktur, değişmedi.
- v0.12.2: Satır modeli: türetilmiş satır (`kind: 'follow'`). Projede kayıt yok, her eşleştirmede tekrar hesaplanır. Son hedefin durumu: kural veya onaylı karar → 301 o hedefe (`follow`); 410 → 410 (`follow`, `gone`); onay bekliyor, öneri yok veya kontrol edilemedi → `wait` ("Bekliyor", karar sayılmaz: hedefin kendi satırı kararı ister); haritada satırı yok (yeni sitede aynı yolda) → 301 canlı eski alan adı + yol; staging hedefi doğru yönlendiriyor → staging hedefinin canlı adresi; ana sayfa → 301 ve soft 404 uyarısı. Kullanıcının satıra verdiği karar kazanır (`project.map`, diğer kararlar gibi). "Geri al" satırı izlemeye döndürür. Liste kalkınca karar silinmez ("artık gerekli değil").
- v0.12.2: Satır almayanlar: son hedef eski sitede hata veriyor (404, 0, döngü; liste sonucu yeni tür `redirectBad` "Yönleniyor · hedef hata") ve geçecek site bu adresi sayfa olarak sunuyor (adres yeni sayfanındır).
- v0.12.2: Kendi kararı gereken satırlar: hedef eski sayfa değil (liste modunda linksiz hedef, dosya): öneri hedefin adresinden gelir (aynı `suggestTargets` çağrısı, neden metni "Eski hedef /x: …"). Hedef başka alan adında: "Onay bekliyor", öneri aynı dış adres (`ext: true`, onay `{ url }` kararı olur); dış adres staging alan adı ise (projedeki staging hostu veya `stagingHosts`/`stagingSuffixes`) "Öneri yok".
- v0.12.2: Staging: yeni istek yok. Staging taraması bu yolu yönlendirme olarak bulduysa satır `staging: 'installed'` (hedef yol ve kabul edilen host aynı) veya `'other'` alır. Kurulu satır Yapılacaklar'da iş olmaz.
- v0.12.2: Canlı doğrulama: beklenen liste istek atmadan kurulur (v0.11.0). Kaynak metinleri: "Eski yönlendirme" (301), "Eski yönlendirme · 410", kendi kararı "Onay"/"Elle"/"410", bekleyen "Karar yok · eski yönlendirme". Yeni sonuç türü `ok-left` (Tamam): beklenen hedef dış adres ve tek adım 301/308 Location bu adres ise. Araç dış alan adına istek atmaz.
- v0.12.2: Yapılacaklar: `follow` satırı sunucu işi ("301 kurun" veya "410 verin"). Canlıya çıkış: 301 listesindeki staging adresi kontrolü `follow` satırlarını da kapsar. CSV: `follow` satırları girer, kaynak "Eski yönlendirme". Excel "301 haritası": durum "Hedefi izler (301)" / "Hedefin kararı bekleniyor", "Eski sayfa nereden" = "Eski yönlendirme (liste|tarama)", Neden sütununda "Eski sitede → /x".
- v0.12.2: Arayüz: 301 haritasında yeni kutu "Eski yönlendirmeden" ve sekme "Eski yönlendirme" (satır varsa). Satır etiketleri "Eski yönlendirme", "İzliyor" (yeşil) veya "Bekliyor" (amber), "Eski sitede → /x" ve "Başka adres seç" (seçim kutusu, "Vazgeç"). Liste kartında yönlenen adres kutusu "eski sitede yönleniyor · 301 haritasında", kırık hedef ayrı kutu. Ekran görüntüsü 1440 ve 390 px: harita (Eski yönlendirme, Onay bekliyor, Başka adres seç), Tarama adımı liste kartı, Yapılacaklar. Taşma ve konsol hatası yok (Google Fonts isteği hariç).
- v0.12.2: Testler. `test/redirects-test.js` (13 kontrol), test sitesi `startRedirectSites` (`test/fixture-migration.js`). Dış adresler `.invalid` ve `.example`, staging `staging.ornek.test`. Eski harita koduyla 9 davranış testi başarısız oldu (geçen 4: yeni fonksiyonların birim testi ve "satır yok" kontrolü; tam eski kodda dosya modül hatası verir). `test/urllist-test.js` içinde iki beklenti değişti (karar 5): liste sonuçlarına `redirectBad: 0` eklendi; `/eski-indirim` ve `/disari` artık haritada `follow` satırıdır. Diğer testler aynen geçti. Yeni bağımlılık yok. Yeni eşik yok.

- v0.12.1: Eski adres listesi, ikinci parça. A, B, C (trafik sırası) onaylı plan idi, doğrudan yazıldı. D (karar 7b) için önce deney ve tasarım yapıldı, kullanıcı dört öneriyi onayladı ("Devam et").
- v0.12.1: Trafik sırası. Yapılacaklar: işler önce yere göre (kart sırası), sonra trafiğe göre (`buildTodo` → `traffic`). Sıralama kararlıdır: trafiği olmayan iş kendi türünün sırasında sonda kalır. Canlıya çıkış: "Karar bekleyen" satırları trafiğe göre ("Onay bekliyor" ve "Öneri yok" karışık). Canlı doğrulama: `expectedList` haritayı trafik ile kurar, satırlar trafik sırasında; her grupta liste trafiğe göre. Yayın modunda kontrol sınırı (`yayin.maxUrls`) önce düşük trafikli adresi dışarıda bırakır. Etiket ve Excel sütunları 301 haritası ile aynıdır.
- v0.12.1: Plandan fark (kullanıcıya yazıldı): Excel "Canlıya çıkış" sayfası da trafik sütunu aldı. Neden: satırlar trafiğe göre sıralı, sayı olmadan sıra anlaşılmaz.
- v0.12.1: Canlı doğrulama önbellek anahtarı satır sırasına ve trafiğe bağlı değil (sıralı satır listesi). Yeni liste kaynağı sırayı değiştirir ama istekleri tekrarlatmaz. Önbellekteki cevaplar güncel satır sırası ve trafik ile birleşir. Geç adresin kanıtı anahtara girer (kanıt sonucu değiştirir).
- v0.12.1: Geç adres (karar 7b). Deney: bugünkü kodda çıkıştan sonra eklenen iki adres (biri eski sitede var, biri hiç yok) 301 haritasında ve canlı doğrulamada yoktu, canlı alan adına istek gitmedi. Tanım: listede olup eski site taramasında ve liste taramasında olmayan yol, sadece çıkış işareti varsa (`latePaths`). Kapsam (karar 1): çıkıştan sonra eklenen kaynak ve çıkıştan önce eklenip istenmeyen adres; ikisi de eski sitede kontrol edilmedi. Liste ekranında sonuç "Canlıda kontrol edilir" (eski ad "Çıkıştan sonra geldi"). Yeni kayıtlı alan yok: küme her istekte hesaplanır.
- v0.12.1: Geç sayfa içeriksiz eski sayfadır (`withLatePages`: `late: true`, title, H1 ve içerik yok). v0.12.0 kuralı ("liste sayfası sadece HTML 200 ise eklenir") ile farkı: karar 7b bunu onayladı; sayfa işaret taşır ve hiçbir yerde "200 verdi" yazılmaz. Karşılaştırma: eski anahtar sayılmaz (eski sayfa sayısı, korunan oran, bölüm tablosu, kural önerisi ve hazırlık eşiği görmez, `summary.late` ayrı sayıdır); içerik farkı aranmaz (boş title yanlış "İçerik değişti" verirdi); aynı yolda yeni sayfa varsa satır olmaz. 301 haritası satırı `late: true` alır, arayüz "İçerik yok" etiketi gösterir; öneri sadece adres benzerliğidir (kod değişmeden: boş alanlar puana girmez).
- v0.12.1: Staging isteği (karar 3): geç adres staging'e istenmez. Yeni taramada yoksa "Kayboldu" kalır, kural hedefi taramada varsa "Hedef hazır, 301 eksik" (301 kurun işi), hedef yoksa "Hedef yok", kaldırılan bölümde "Bölüm kaldırıldı". Neden: çıkıştan sonra staging kapanmış olabilir ("Kontrol edilemedi" olur ve haritada öneri çıkmaz). Canlı doğrulama gerçek durumu canlı alan adında ister. Deney: eşleştirme istekleri geç adresleri içermez, canlı doğrulama istekleri içerir (test).
- v0.12.1: Bozuk liste (karar 2). Geç adres canlıda hata verirse: listede bir ölçü `urlList.lateProof` eşiğinde veya üstündeyse kritik "Kayıp sayfa · haritada karar yok", değilse "Kontrol edilemedi" grubunda yeni tür "Eski sitede var mıydı bilinmiyor" (`late-unproven`). Düz liste sayı taşımaz, kanıt değildir. Search Console satırı neredeyse her zaman kanıttır. Wayback Machine önerilmedi: başka alan adına istek atar. Karar varsa (301, 410) satır normal beklenti alır. Kaynak sütunu "Karar yok · liste".
- v0.12.1: Testler. `test/urllist-test.js` 10 yeni kontrol (toplam 30): 5 trafik sırası (Yapılacaklar, Canlıya çıkış, Canlı doğrulama, iki Excel sayfası), 2 birim (geç adres kümesi ve kanıt; karşılaştırmada içerik farkı yok, sayılara girmez, istek işareti yok), 3 API (staging ve eski siteye istek yok, haritada "İçerik yok" ve adres önerisi; canlıda kanıtlı kritik, kanıtsız kontrol edilemedi, açılan tamam; karar beklentiyi değiştirir, liste kalkınca karar kalır, Excel). Test sitesine linksiz `/gec-sayfa` eklendi. Yeni 10 kontrol eski kodda başarısız oldu, yeni kodda geçti. Eski testler aynen geçti.
- v0.12.1: Ekran görüntüsü 1440 ve 390 px: Yapılacaklar (karar listesi açık), Canlıya çıkış (karar bekleyen listesi açık), Canlı doğrulama (kritik ve "bilinmiyor" listeleri açık), çıkıştan sonra 301 haritası ve Tarama adımı (liste kartı). Taşma ve konsol hatası yok. Yeni bağımlılık yok.

- v0.12.0: Eski adres listesi (kullanıcı sohbette tıklanabilir taslağı ve 10 kararı onayladı). Sorun deney ile doğrulandı: eski sitede 200 veren linksiz sayfa taramada, 301 haritasında ve canlı doğrulama listesinde yoktu. İkinci deney: sayfa eski tarama sayfalarına eklenince eşleştirme, harita ve doğrulama kodu değişmeden onu kullandı. Tasarım buna dayanır: listeden bulunan sayfa eski sayfa kümesine girer (`projectInputs` → `listInputs` → `withListPages`). Bütün adımlar onu taranmış sayfa gibi kullanır.
- v0.12.0: Kararlar. (1) Kart Tarama adımında, ayrı adım yok. (2) En fazla 5 kaynak. Aynı yol birleşir; tıklama, gösterim ve görüntüleme toplanır; link veren alan adı büyük değeri alır (aynı alan adı iki sürüme link verir). Aynı dosya (içerik özeti) iki kez eklenmez. (3) Trafik sırası: tıklama, gösterim, görüntüleme, link veren alan adı. Ölçüsü olmayan satır sonra gelir. (4) robots.txt: tarama ayarındaki seçim kullanılır. (5) Eski sitede yönlenen adres haritaya girmez, listede ve Excel'de görünür. (6) Eski sitede 404 veren adres sadece listelenir. (7) Çıkıştan sonra eklenen liste: içeriksiz eski sayfa (v0.12.1). (8) "Projeyi indir" listeyi taşır (adres ve trafik), sayfa içeriği taşınmaz. (9) Sıradaki iş kartı liste yokken liste istemez; istenmemiş adres varsa "N adres taramada yok. Eski sitede isteyin." (eşleştirmeden önce). (10) İki sürüm: v0.12.0 ve v0.12.1.
- v0.12.0: Taslaktan iki fark (kullanıcıya yazıldı): Excel "Eski adres listesi" sayfası v0.12.0'a girdi (karar 5 bunu gerektiriyordu). Liste proje dosyasında değil, ayrı dosyada (`crawls/projects/lists/<id>.json`): kenar çubuğu her proje dosyasını okur, 30.000 satır onu yavaşlatırdı. Projede sadece istek durumu durur (`urlList.crawlId`, `pendingCrawlId`, `lastError`). v0.7.0 kuralı (projede sonuç yok) korunur: sayfa içeriği liste taramasında (`crawls/<id>.json`, etiket `liste`) durur.
- v0.12.0: İstekler. Sadece listede olup eski site taramasında olmayan yollar istenir (her durum: tarama 404 veya yönlendirme bulduysa tekrar istenmez). İstek eski site taramasının başlangıç adresi ile kurulur (aynı şema ve host). Tarayıcı liste modunda link izlemez ve sitemap okumaz. Aynı hosttaki yönlendirme izlenir (hedef ayrı sayfa olmaz). Başka hosta giden adımda durur ve isteği atmaz (`offHost`). Yayın modunda SSRF koruması ve `yayin.maxUrls` sınırı (trafiği yüksek olan önce). Liste taraması denetim çalıştırmaz.
- v0.12.0: Temizlik. Adres tam URL, `/yol` veya `alan.adi/yol` olabilir. Normalizasyon tarayıcı ile aynıdır (izleme parametreleri, hash). www ve http/https aynı sitedir. Anahtar `pathKey` (sondaki `/` yok). Başka alan adı sadece sayı olarak saklanır. Dosya adresleri (pdf, görsel; `looksLikeAsset`) atlanır. Sayılar tam sayıdır: bütün ayırıcılar silinir (1.240, 1,240 ve "1 240" = 1240).
- v0.12.0: Sütun tanıma. Başlık satırı ilk 10 satırdaki bilinen adres sütunu ile bulunur. Başlık yoksa çoğu hücresi adres olan sütun kullanılır (düz liste). Kaynak türü sütunlardan gelir: tıklama veya gösterim = Search Console, görüntüleme = Analytics, link veren alan adı = backlink, hiçbiri = düz liste. Sütun bulunmazsa sunucu başlık hücrelerini döner, ekran seçim ister.
- v0.12.0: Eski sayfa kümesi. Liste taramasındaki sayfa ancak HTML 200 ise ve yolu hâlâ listede ise eklenir (`discoveredBy: 'list'`, iç link 0). Taramadaki sayfa önceliklidir. Kaynak silinince sayfa düşer, 301 kararı silinmez ("artık gerekli değil" sayılır, liste geri gelince tekrar kullanılır). Karşılaştırma önbelleği anahtarına eklenen sayfaların özeti girer.
- v0.12.0: Kilit. Çıkış işareti liste taramasını da kilitler (`launch.crawls.list`). Çıkıştan sonra `/fetch` 409 verir. Liste taraması sürerken çıkış işaretlenemez. Çıkıştan sonra liste eklenebilir; kaynak `afterLaunch` alır, adresleri "Çıkıştan sonra geldi" sayılır.
- v0.12.0: Arayüz. Kart başlığı "İsteğe bağlı" etiketi taşır. Yükleme paneli önce okur (önizleme, kaydetmez), sonra ekler. Ekranda tek kırmızı düğme kalır (Sıradaki iş). Liste taraması "Var olan tarama" seçeneklerinde görünmez (yanlış bağlama riski, ekran kontrolünde bulundu). Kısa liste istek cevabından önce biter: ekran listeyi her durumda tekrar yükler (ekran kontrolünde bulundu). Mobilde liste tablosu karta dönüşür. Ekran görüntüsü 1440 ve 390 px: yükleme paneli, liste eklendi, istek bitti, 301 haritası, çıkıştan sonra. Taşma ve konsol hatası yok.
- v0.12.0: Testler. `test/urllist-test.js` (20 kontrol). Örnek CSV test içinde üretilir. Test sitesi bütün istekleri sayar: liste istekleri sadece eski siteye gider ve taramadaki yol tekrar istenmez. Yeni test eski kodda başarısız oldu (modül yok), yeni kodda geçti. Eski testler aynen geçti (test sitesindeki yeni sayfalar linksiz olduğu için eski sayıları değiştirmedi).
- v0.12.0: `package-lock.json` sürüm alanı v0.10.4'te kalmıştı. 0.12.0 yapıldı. Bağımlılık değişmedi. Yeni bağımlılık yok.

- v0.11.0: Parça 3b, canlı doğrulama (kullanıcı sohbette taslağı ve 10 kararı onayladı). Amaç: canlıya çıkıştan sonra taşımanın doğru yapıldığını kanıtlamak. Kontroller: A) her eski adres canlı alan adında (301, 410, sayfanın kendisi), B) staging ayarı canlıda (noindex, X-Robots-Tag, `Disallow: /`, açık yazılmış staging adresi), C) eski sitenin etiketleri (Analytics/GTM, Search Console), D) sitemap (sadece canlı adresler, adresler 200).
- v0.11.0: Çıkış işareti ("Canlıya çıktık" + tarih, `project.launch`). v0.10.0 kuralı ("elle tamam işareti yok") ile çelişmez: işaret projenin aşamasını yazar, hiçbir kontrolün sonucunu değiştirmez. Bütün sonuçlar istekten ve taramadan gelir. Neden: araç çıkış anını başka yoldan bilemez ve eski site taramasını korumak için kilit gerekir.
- v0.11.0: Kilit. İşaretten sonra eski site ve staging taramaları tekrar taranamaz (sunucu 409 verir, arayüz "Kilitli" yazar). Neden: çıkıştan sonra eski alan adı yeni siteyi sunar; eski siteyi tekrar taramak eski sayfaları kaybettirir. PUT kilitli tarama kimliğini ve işareti değiştirmez. İşaret kalkınca kilit kalkar. Çıkıştan sonra biten çıkış öncesi tarama projeye bağlanmaz.
- v0.11.0: Beklenen liste istek atmadan hesaplanır (çıkış öncesi taramalar + güncel kararlar). Deney: eşleştirme ekranının 301 haritası staging'e istek atar; staging'de kurulan 301 o listeden düşer (2 satır → 1 satır). İstek olmadan liste sabittir. İstek olmadan taşınan sayfalar `moving` grubunda kalır: hedefi taramada olanlar kural satırı, olmayanlar öneri satırı olur (CSV ile aynı). Karar, staging yönlendirmesinden önce gelir.
- v0.11.0: Kapsam: haritadaki 301 ve 410 satırlarına ek olarak staging'de aynı adreste açılan sayfalar (200 beklenir) ve kararı olmayan sayfalar ("Karar yok": 404 ise kritik "Kayıp sayfa", açılıyor veya tek adımda yönleniyorsa Tamam ve not). Böylece her eski sayfa kontrol edilir.
- v0.11.0: Dört grup: Kritik, Düzeltin, Kontrol edilemedi, Tamam. "Kontrol edilemedi" tamam sayılmaz. Sonuç türleri ve grupları `src/verify.js` → `R` tablosundadır. 410 yerine 404 "Düzeltin" grubundadır (Google iki yanıtı da kaldırır, 410 daha hızlıdır).
- v0.11.0: İstekler sadece projenin canlı alan adlarına gider (eski alan adı ve ek sitelerin canlı alan adı). Başka hosta giden adım istenmez: staging ise kritik "Yanlış hedef: staging", değilse "Hedef proje dışında" (Kontrol edilemedi). Yayın modunda her adım SSRF korumasından geçer ("İç ağ adresi"). Aynı adres bir kontrolde bir kez istenir. Yayın modunda en fazla `yayin.maxUrls` adres kontrol edilir.
- v0.11.0: Sonuç sunucu belleğinde proje başına `compare.probeCacheMin` dakika saklanır. Anahtar beklenen listenin özetidir: haritada bir karar değişirse liste hemen tekrar kontrol edilir. "Tekrar kontrol et" (`?fresh=1`) hemen tekrar ister.
- v0.11.0: Canlı tarama ayrı kimlik alır (`sites[].liveCrawlId`, `pendingLiveCrawlId`, `liveError`). Staging taraması ile karışmaz. Geçecek site eski alan adında, ek site canlı alan adında taranır. Eski site canlıda taranmaz. Canlı alan adı yazılmamış ek site kontrol edilemez: kart ve satır nedeni yazar, iş "Projeyi açın". Canlı alan adı sonra değişirse tarama "eski alan adında" olur.
- v0.11.0: "Geçiş yapılmadı" uyarısı: 301 beklenen adreslerin en az `verify.notSwitchedRatio` (0.8) oranı yönlenmeden 200 veriyorsa (en az `notSwitchedMin` 3 adres) Sıradaki iş kartı DNS geçişini kontrol etmeyi söyler.
- v0.11.0: Kod paylaşımı: staging adresi, noindex/Disallow ve etiket kontrolü `launch.js` içinden ayrıldı ve iki modül tarafından kullanılır. `buildLaunch` davranışı değişmedi (11 test aynen geçti). Proje girdileri (taramalar, kurallar, canlı alan adları) `server.js` → `projectInputs` içinde: eşleştirme ve canlı doğrulama paylaşır.
- v0.11.0: Sitemap: sadece 200 veren sitemap dosyası sayılır (tarayıcı denediği `/sitemap.xml` 404 dosyasını da listeye yazar). Canlı sitede sitemap açılmıyorsa ve eski sitede vardı veya robots.txt sitemap adresi veriyorsa "Sitemap bulunamadı". Başka alan adı: canlı alan adı dışındaki ve staging olmayan hostlar.
- v0.11.0: Excel "Canlı doğrulama" sayfası (çıkış işareti varsa): Grup, İş, Site, Ekip, Tür, Adres, Beklenen, Canlıda, Son adres, Kaynak, Not, Durum. Adres işlerinin yeri "<eski alan adı> sunucusu". Excel kayıtlı sonucu kullanır.
- v0.11.0: Test sitesindeki başka alan adı `.example` ile yazılır: `.test` eki `stagingSuffixes` içinde olduğu için staging sayılır. Yeni testler eski kodda başarısız oldu (verify-test modül bulamadı, sunucu testinin 2 yeni kontrolü başarısız), yeni kodda geçti.
- v0.11.0: Tanıtım sayfasındaki (docs) adım listesi güncellendi: "Canlıya çıkış · Sonraki sürüm" v0.10.0'dan beri eskiydi. Canlıya çıkış ve Canlı doğrulama eklendi.
- v0.11.0: Yeni bağımlılık yok.

- v0.10.4: README baştan yazıldı (kullanıcı istedi). Yeni yapı: aracın konumu (site taşıma aracı), "Araç ne yapar" bölümü (tam yaptığı, kısmen yaptığı ve yapmadığı işler), site denetimi, taşıma projesi, komut satırı, sunucu, doğrulama, geliştirme, sınırlar, yol haritası. Sürüm etiketleri (v0.7.0 gibi) README'den çıktı: geçmiş bu dosyadadır. Yol haritası v0.10.2 sırasına göre yazıldı. Akış şeması Mermaid ile (GitHub kendisi çizer). "Tam yaptığı işler" notu: kod ve test tamam, gerçek site ölçümü sürüyor. Doğrulama ölçümü bitince bu notu güncelleyin.
- v0.10.4: `.env.example` içindeki "şifreyi zorunlu yapar" yorumu düzeltildi (v0.8.4'ten beri şifre isteğe bağlı).

- v0.10.3: Yükleme yöntemi değişti (kullanıcı istedi: "sadece yükleyeceğim dosyayı ver"). Neden: v0.10.1 ve v0.10.2 yüklemeleri depoya düz girdi (klasör sürükleme kullanıcının ortamında çalışmadı), 21 dosya kök klasöre kopyalandı ve `src/`, `public/`, `test/` eski sürümde kaldı. Çözüm: kullanıcı zip dosyasını açmadan köke yükler, GitHub Actions iş akışı (`.github/workflows/guncelle.yml`) gerisini yapar. İş akışı üçüncü taraf action kullanmaz (sadece git, unzip, npm). Yetki: `contents: write`, sadece `main` dalına `*.zip` push'unda çalışır. `SIL.txt` içinde `/` ile başlayan, `..` içeren veya `.github` ile başlayan yol atlanır. İş akışı dosyasını kullanıcı web'de bir kez elle oluşturur: GITHUB_TOKEN iş akışı dosyası yazamaz.
- v0.10.3: Zip dosyaları depo geçmişinde kalır (her biri yaklaşık 200 KB). Kabul edildi. Arkadaşın Pull Request düzeni değişmedi.

- v0.10.2: Konum kararı (kullanıcı onayladı). Araç genel bir denetim aracı olarak yerleşik tarayıcılar ile yarışmaz. Hedef: site taşıma aracı. Anahtar kelime takibi, backlink veritabanı ve hız laboratuvarı yapılmaz; bu veri hazır servislerden alınır (Search Console, PageSpeed API).
- v0.10.2: Yeni sıra (kullanıcı onayladı, Claude'un önerisi): (1) doğrulama, (2) Parça 3b canlı doğrulama, (3) eski URL listesi ve Search Console verisi, (4) JS render (Sprint 6 öne alındı; Playwright yeni bağımlılıktır, başlamadan önce onay gerekir), (5) paylaşılabilir rapor ve ClickUp işi, (6) canlıdan sonra izleme (1, 7, 30 gün). Sprint 4 (AI) ve PageSpeed bu sıradan sonra tekrar konuşulur.
- v0.10.2: Doğrulama komutu depoya girer, veri girmez. Rapor dosyaları `crawls/` içine yazılır (.gitignore). CSV okuyucu kendi kodumuzdur: yeni bağımlılık yok. Karşılaştırma mantığı `src/validate.js` içindedir ve testi vardır (`test/validate-test.js`); kural motoruna girmez.
- v0.10.2: v0.10.1 yüklemesi depoya düz girdi (klasörler olmadan): 18 dosya kök klasöre kopyalandı, `src/`, `public/`, `test/` ve `config/` v0.10.0'da kaldı. v0.10.2 zip dosyası v0.10.1 değişikliklerini de içerir. Kök klasördeki 18 kopya silinmeli. Ders: zip içeriğini klasörler ile sürükleyin, dosyaları tek tek seçmeyin.


- v0.10.1: Kod incelemesi (kullanıcı istedi). 12 hata deney ile doğrulandı ve düzeltildi. Her düzeltmenin testi var; yeni testler eski kodda başarısız, yeni kodda geçer.
- v0.10.1: Staging şifresi sadece taranan siteye gider (`crawler.js` → `headersFor`). Başka hosta giden yönlendirme ve başka hosttaki sitemap şifreyi almaz. Sprint 2 kararı ek kontrollerde uygulanıyordu, ana taramada uygulanmıyordu.
- v0.10.1: Zaman aşımı gövde okumasını da kapsar. Gövde akış olarak okunur ve `maxBodyBytes` (5 MB) değerinde kesilir; sayfa `truncated: true` alır. Başlık gelip gövde gelmezse sayfa `status 0`, `error timeout` olur (`http-failed` kuralı).
- v0.10.1: Yerel sunucu Host başlığını kontrol eder: `localhost`, IP adresi veya `ALLOWED_HOSTS`. Neden: DNS rebinding ile başka bir site yerel taramaları (müşteri verisi) okuyabiliyordu. Yazma istekleri (POST, PUT, DELETE) için Origin, Host ile aynı olmalı (her modda). `/healthz` kontrol dışıdır.
- v0.10.1: `isNoindex` yönergeleri tek tek okur (`robotsDirectives`). `max-image-preview:none` noindex değildir. X-Robots-Tag içinde başka bota yazılan yönerge sayılmaz; sadece genel ve `googlebot` yönergeleri sayılır (araç Google için raporlar). Canlıya çıkış listesi de aynı fonksiyonu kullanır.
- v0.10.1: SVG içindeki `<title>` sayfa title'ı değildir. Blok etiketlerden sonra boşluk eklenir: kelime sayısı, parmak izi ve dummy metin araması bitişik etiketlerde doğru çalışır.
- v0.10.1: URL kuralları `safeDecode` kullanır. Bozuk yüzde kodu kuralı durdurmaz, ham yol kullanılır.
- v0.10.1: 301 kontrol sonucu `compare.probeCacheMin` (30) dakika saklanır. "Tekrar kontrol et" düğmesi (`/match?fresh=1`) adresleri hemen tekrar ister. Satır adım çubuğunun altında, eşleştirme kullanan dört adımda görünür ve son kontrol saatini yazar. Neden: 301 kurulduktan sonra sonuç sadece yeni tarama veya sunucu yeniden başlatma ile yenileniyordu.
- v0.10.1: İstek sınırı `rules.json` → `server.maxBodyKb` (4096). Önceki sınır kodda 100 KB idi: yaklaşık 1.000 kararlı proje dosyası yüklenmiyordu. Sınır üstü 413, bozuk JSON 400 verir.
- v0.10.1: Sitemap okuyucu entity genişletmez. Sadece standart XML entity'leri (`&amp;` ve sayısal) elle çözülür. `npm audit fix` ile `fast-xml-parser` 4.5.7 ve `undici` 6.29.1 oldu (sadece `package-lock.json`, aynı ana sürüm). Ana sürüm yükseltmesi gerekmedi. Yeni bağımlılık yok.
- v0.10.1: Tarama kimliği dosya adına uygun yapılır (IPv6 → `ipv6-…`). Aynı saniyede aynı hostun ikinci taraması `_2` ekini alır.


- v0.10.0: Parça 3a, canlıya çıkış listesi (kullanıcı sohbette taslağı ve dört noktayı onayladı). Gruplama zamana göredir, yere göre değildir: Kritik (çıkıştan önce düzeltin), Karar bekleyen, Çıkış anında değiştirin (staging'de normal), Kontrol edin. Her satır siteyi ve ekibi etiket olarak gösterir. Elle "tamam" işareti yok: durum her zaman taramadan gelir.
- v0.10.0: Staging adresini proje bilir. Bir yeni site, tarama alan adı canlı alan adından farklıysa staging'dir (canlı alan adı yazılmamışsa da staging sayılır). Ayrıca `stagingHosts`/`stagingSuffixes` desenine uyan ve canlı olmayan alan adları staging sayılır. Canlı alan adları asla staging sayılmaz.
- v0.10.0: Göreli adres iş değildir. Sadece HTML'de açık yazılmış staging adresi iştir. Bu yüzden parser ham değeri okur (`absHosts`: canonical, hreflang, link, asset). Normalize edilen değer her zaman host taşıdığı için kullanılamaz. Canlı alan adına giden canonical doğrudur.
- v0.10.0: Kritik işler: 301 listesinde staging adresi (son listede, rule ve approved satırları; canlı alan adı yoksa "Projeyi açın", elle yazılmışsa "Haritayı açın"), sitede staging adresi (canonical, hreflang, link, görsel/script/CSS/iframe, sitemap URL'leri, robots.txt `Sitemap:` satırı), staging Google'a açık (şifre yok, `Disallow: /` yok, noindex olmayan sayfa var). Son madde kullanıcının onayladığı ek öneridir.
- v0.10.0: noindex (meta robots ve X-Robots-Tag) ve `Disallow: /` kritik değildir. Staging'de doğrudur, "Çıkış anında değiştirin" grubunda durur. Canlıda aynı bulgu kritik olur (Parça 3b). Kısmi Disallow (`/admin/`) iş değildir.
- v0.10.0: Karar bekleyen: 301 haritasında `pending` ve `none` satırları. Sayı haritanın sayısı ile aynıdır (Yapılacaklar'daki "sayfa oluşturma" ayrımı burada yok).
- v0.10.0: Etiket kontrolü. Analytics/GTM kimliği bütün hedef sitelerde aranır. Eski kimlik yeni sitede hiç yoksa iş olur ("Eksik"). Yeni sitede başka kimlik varsa "Bilgi" satırı olur ve sayılmaz (yeni hesap bilinçli olabilir). Search Console doğrulama etiketi sadece geçecek sitede aranır: ek site yeni alan adıdır, eski doğrulama orada geçerli değildir. DNS ile doğrulanan mülkte etiket gerekmez (not yazar).
- v0.10.0: Yeni veri: `parser.js` → `absHosts`, `tracking` (sadece script ve noscript içinden, sayfa metninden değil), `gscVerify`. `crawler.js` → `meta.sitemap.hosts` (başka hosttaki sitemap URL'leri de sayılır; önceden sessizce düşüyordu). Eski taramada bu veri yoksa liste "Tarama eski · Tekrar tara" der ve o kontrolü yapmaz (yanlış iş üretmez). robots.txt satırı eski taramada da okunur.
- v0.10.0: Canlı alan adında taranan site staging sayılmaz. Staging kontrolleri o sitede çalışmaz. Etiket kontrolü çalışır.
- v0.10.0: Kontroller kural motoruna (`definitions.js`) girmez. Proje kontrolüdür (`src/launch.js`), çünkü canlı alan adını ve 301 haritasını bilmesi gerekir. Test kuralı yine uygulandı: `test/fixture-launch.js` tetikleyen siteleri, `test/launch-test.js` beklentileri içerir. Şifreli "temiz" staging hiçbir iş üretmez (`/temiz` kuralının karşılığı).
- v0.10.0: Sıradaki iş kartı (Canlıya çıkış adımında): önce kritik iş, sonra karar, sonra kontrol, sonra çıkış ayarları ("Excel indir"). Liste temizse "Staging canlıya çıkışa hazır görünüyor". Yapılacaklar boşsa kart Canlıya çıkışı önerir.
- v0.10.0: Excel'de "Canlıya çıkış" sayfası: Grup, Site, Ekip, İş, Tür, Adres, Değer, Not, Durum. Her adres bir satırdır. Ekranda bir işin listesi en fazla `launch.listLimit` (200) satır gösterir.
- v0.10.0: "Yeni yapı nasıl?" iki seçenek oldu: "Tek alan adı" ve "Diller ayrı alan adlarına" (kullanıcı onayladı). "Aynı yollar" ve "yollar değişiyor" aynı işi yapıyordu: yol farkını araç eşleştirmede bulur. Eski proje dosyasındaki `paths` değeri `same` okunur.
- v0.10.0: Adım çubuğu: Canlıya çıkış aktif. Sadece Canlı doğrulama "Sonraki sürüm".
- v0.10.0: Yeni bağımlılık yok (robots-parser zaten vardı).

- v0.9.1: Gerçek kullanımda kafa karışıklığı (Doyuyo): Yapılacaklar listesindeki "Yeni adres" sütunu bazı satırlarda staging adresini gösteriyordu. Kullanıcı bunu "eski adresi staging'e yönlendiriyoruz" diye okudu. Düzeltme: her işin iki adresi var. `liveUrl` = canlıya çıkıştan sonraki adres (geçecek site için eski alan adı, ek site için projedeki canlı alan adı). `checkUrl` = aracın kontrol ettiği adres (staging). Ekranda ve Excel'de ayrı sütunlar: "Canlı adres" ve "Kontrol edilen adres". Canlı adres link değildir (canlıda sayfa henüz yok). Canlı alan adı yoksa canlı adres boş kalır ve ekran "Canlı alan adı yok" der: staging adresi asla canlı adres gibi yazılmaz.
- v0.9.1: Kural: 301 hedefi her zaman canlı alan adıdır. Staging sadece karşılaştırma ve test içindir. Staging'de test edilen kural staging içinde çalışır (`staging/eski` → `staging/yeni`). Canlıdan staging'e yönlendirme hiçbir aşamada olmaz.
- v0.9.1: Linksiz sayfa notu değişti: "Sayfa yeni sitede aynı yolda var. 301 gerekmez. Menüden veya içerikten link verin." Eski metindeki "Sayfa gereksizse 301 ile yönlendirin" cümlesi satırı yönlendirme işi gibi gösteriyordu. Sayfa oluşturma ve harita kararı notları da adres içermez (adres sütunlarda).
- v0.9.1: "Hazır 301 listesini içe aktar ve kontrol et" özelliği yapılmayacak (kullanıcı kararı). Neden: 301 listesini bu araç üretir. Örnek dosya (eski bir projeden, SEO uzmanının listesi) staging adresli hedefler, toplu ana sayfa yönlendirmesi, sonda boşluk ve tutarsız `/` içeriyordu. Bu sorunları aracın kendi listesi zaten önler (canlı alan adı, soft 404 uyarısı, CSV temizliği).
- v0.9.1: Parça 3a için not: "301 listesinde staging adresi" kontrolü kritik madde olarak listeye girer. (v0.10.0 ile yapıldı.)

- v0.9.0: Yapılacaklar ekranı (kullanıcı sohbette taslağı onayladı). Her yer bir karttır: başlık + "?", ekip etiketi (Backend, CMS, İçerik, Siz), iş sayısı, iş satırları, "Listeyi aç". Sıra: eski alan adı sunucusu, geçecek site, ek siteler, İçerik, Karar bekleyen. Eski grup görünümü kapalı "Bütün sayfalar" bölümünde kalır.
- v0.9.0: CLAUDE.md'deki v0.7.0 tasarımından fark: geçecek site de ayrı satırdır (tasarım "her ek site" diyordu). Neden: "Sayfa oluşturun" işi geçecek sitede de olur.
- v0.9.0: İşlerin yeri. Sunucu: 301 haritasının son listesinde (CSV ile aynı) olup çalışmayan 301'ler (kural satırı kurulu değilse, onaylı satır), zincir veya 302 olan yönlendirmeler (hedefi kırık olan haritadadır), 410 kararları. Yeni site: kural hedefi olmayan sayfa (haritada karar yoksa), haritada seçilen ama taramada olmayan hedef, linksiz sayfa, linksiz taşınan hedef. İçerik: her kayıp alan bir iştir. Karar bekleyen: haritada onay bekleyen veya önerisiz satır (sayfa oluşturma işi olanlar hariç, iki kere sayılmaz), bölüm uyarısı, kontrol edilemeyen sayfa. Her iş bir siteye bağlıdır (beklenen site).
- v0.9.0: Site hazırlık kontrolü (kullanıcının fikri, onaylandı). Ölçü: sitenin taramadaki 200 veren HTML sayfa sayısı < o siteye giden eski sayfa sayısı × `todo.notReadyRatio` (0.3), en az `notReadyMinOld` (10) eski sayfa ile. "Bulunan sayfa oranı" kullanılmadı: slug değişince hazır site de düşük oran verir. Kaldırılan bölümün sayfaları hiçbir siteye sayılmaz. Hazır görünmeyen sitenin işleri bekler: sayılmaz, site kartında soluk "Bekleyen iş" olarak durur, Excel'de "Bekliyor" yazar. Sunucu işleri beklemez. Liste gizlenmez.
- v0.9.0: Kullanıcı "Site hazır, uyarıyı kapat" ile siteyi hazır sayar. Kabul tarama kimliğine bağlıdır (`project.readyOk`): yeni tarama kabulü düşürür. "Hazırlık uyarısını geri aç" kabulü siler. Proje `PUT` kabulü silmez.
- v0.9.0: Hazırlık kontrolüne girmeyenler: taranmamış site (Sıradaki iş kartı zaten söyler), şifreli staging (Karar bekleyen → Kontrol edilemedi), staging'de noindex veya Disallow (staging için normal, Parça 3'te kontrol edilir).
- v0.9.0: Sıradaki iş kartı: hazır görünmeyen site, bölüm uyarısından sonra ve 301 haritasından önce gelir ("Türkçe tekrar tara"). Yapılacaklar adımında kart listeyi izler: haritada karar varsa "Haritayı açın", yoksa en çok işi olan yer ve "Excel indir".
- v0.9.0: Kavram açıklamaları tek sözlükte durur (`public/app.js` → `TERMS`). Her terim her ekranda aynı metni gösterir. Mobilde açıklama kutusu kartın genişliğini alır (taşma yok).
- v0.9.0: Excel'de "Özet"ten sonra "Yapılacaklar" sayfası: Yer, Ekip, İş, Eski URL, Yeni URL, Not, Durum. Ekranda bir yerin listesi en fazla `todo.listLimit` (200) satır gösterir.
- v0.9.0: Yeni bağımlılık yok.

- v0.8.4: Render şifresiz çalışır (kullanıcının son kararı, v0.5.0 ve v0.4.1 kararlarının şifre kısmının yerine geçer). Claude riskleri yazdı ve şifreli kalmayı ve şifresiz demo modunu önerdi; kullanıcı tam kaldırmayı seçti. Kod: yayın modunda APP_PASS yoksa sunucu açılır ve uyarı yazar. APP_PASS tanımlı ise eski kural geçerli (APP_USER ve en az 10 karakter). SSRF koruması ve yayın limitleri (2.000 URL, aynı anda 1 tarama) değişmedi. `render.yaml` artık APP_USER ve APP_PASS istemez.
- v0.8.4: Şifresiz yayının kuralları: Render'da müşteri sitesi taranmaz, müşteri projesi tutulmaz. Herkes projeleri görür, Excel indirir ve siler. Müşteri işleri yerelde (`npm start`, 127.0.0.1) yapılır.

- v0.8.3: Depo açık kalır (v0.4.3 kararı geçerli). Kullanıcı önce gizli depoyu seçti, sonra vazgeçti. Claude depoyu klonlamaya devam eder. Landing'de "Kodu inceleyin" düğmesi ve GitHub linki var.
- v0.8.3: Landing page (kullanıcı onayladı). Proje iş listesinden ayrı bir görev, Sprint 3 sırasını değiştirmez. Yer: `docs/index.html`, yayın: GitHub Pages (Settings → Pages → main, /docs) veya Netlify (yayın klasörü `docs`). Uygulamanın içinde değil, çünkü: yayın modunda uygulama şifre ister, Render ücretsiz plan uyur (ilk açılış yavaş), portfolyo linki şifre denemesi çeker. v0.4.1 kararı (sunucuyu herkese açma) korunur.
- v0.8.3: Tasarım yönü "kadastro paftası" (frontend-design skill ile, üç yönden kullanıcı seçti). Eski site = mavi ölçü çizgisi, yeni site = kırmızı kesik sınır, sorun = kırmızı nokta, ekip = kare. Renk: pafta zemini #E6EDE3, grafit #2B2E2A, ölçü mavisi #2F5D8C, sınır kırmızısı #B3261E, ızgara #D3DECF. Yazı: Overpass (Google Fonts). Uygulama teması (grafit + kırmızı) kopyalanmadı: landing kendi kimliğini taşır. Tek hareket: eski parseller çizilir, yeni sınırlar gelir, iki sorun işareti düşer; prefers-reduced-motion açıksa yok. Parsellere sayfa yolları yazılır (/urun → /kahveler).
- v0.8.3: Düzen tam genişliktir (kullanıcı istedi). Izgara bütün ekranı kaplar, bölümler tam genişlik bantlardır, bantlar arasında pafta çizgisi var. Hero ekran yüksekliğindedir, çizim sağ kenara uzanır. Metin satırı dar kalır (40-45 karakter). İlk sürümdeki ortada çerçeveli kâğıt düzeni bırakıldı: geniş ekranda küçük ve belge gibi duruyordu.
- v0.8.3: Ekran görüntüleri örnek sitelerden alındı (kavrulmus.example: eski site, staging, İngilizce site; RFC 2606 alan adları). Müşteri verisi yok. Örnek site depoya girmez.
- v0.8.3: "Uygulamaya girin" düğmesi `docs/index.html` sonundaki `APP_URL` sabitini kullanır. Boş ise düğme gizlidir. Adres yazılırsa landing'i açan herkes görür: karar kullanıcıda. Uygulama şifreli kalır (v0.4.1).

- v0.8.2: README başlığındaki sürüm (v0.6.1'de kalmıştı) kaldırıldı. Sürümün tek kaynağı `package.json`. İş sonu kuralına README eklendi (Çalışma döngüsü, 5. adım).
- v0.8.1: Belge değişiklikleri. "İki kişi çalışma kuralları" ve "Doğrulama planı (bekliyor)" bölümleri eklendi. Render'daki tek tarama sınırı Durum'a not olarak yazıldı.
- v0.8.1: Dil filtresi. Her sayfanın dili `html lang` ana etiketidir (tr-TR → tr). Öneri aramasında sıra: (1) eski sayfanın dili bir yeni sitede varsa sadece o dildeki sayfalar; (2) dil biliniyor ama hiçbir yeni sitede yoksa sadece geçecek site (Fransızca → İngilizce site, Türkçe siteye asla); aday yoksa öneri yok; (3) dil bilinmiyor ve bölüm kaldırıldıysa geçecek site (adayı varsa); (4) bölüm kararı (prefer) bu kümede adayı varsa. Dil, bölüm kararından önce gelir: yanlış bölüm kararı yanlış dilde öneri üretmez. AI gerekmez, ücretsizdir.
- v0.8.1: Bölüm uyarısı (`sections[].alert`). Türler: `lang` (bölüm sayfalarının dili ile seçilen sitenin dili farklı ve bölüm dilinde site var), `zero` (kayıtlı karar taramada 0 sayfa buluyor, başka seçim buluyor), `lang-drop` (bölüm kaldırıldı, ama bölüm dilinde site sayfaları buluyor). Uyarı daha iyi seçimi söyler, "Bu seçimi kullan" düğmesi kararı kaydeder. Kendiliğinden uygulanmaz. Sıradaki iş kartı uyarıyı 301 haritasından önce gösterir (harita adımında göstermez). Bölüm ve site dili: dili bilinen sayfaların en az `compare.langMinShare` (0.6) oranı.
- v0.8.1: Ana sayfa adayı. Son yol parçası `redirectMap.homeSlugs` içinde olan eski sayfa (home, anasayfa, page-daccueil…) veya dil bölümünün kökü (/tr, /en-gb) ana sayfa sayılır. Bu sayfaya doğru sitenin ana sayfası (aynı dil, yoksa geçecek site) `homeScore` (85, Yüksek) ile ilk aday olur. Ana sayfa başka hiçbir sayfa için aday olmaz (soft 404 kuralı korunur).
- v0.8.1: Excel "301 haritası" sayfası her satırda Kaynak (Bölüm kuralı, Araç önerisi, İlk öneri onaylandı, Listeden başka öneri, Elle yazıldı, 410, 410 (araç öneri vermişti)) ve aracın en iyi önerisini (adres, güven, puan, neden) gösterir. Öneri her eşleştirmede tekrar hesaplanır: sütun o anki öneriyi gösterir, onay anındaki öneriyi değil.
- v0.8.1: Yeni bağımlılık yok.
- v0.8.1: Sıra değişmedi (kullanıcı onayladı). Önce v0.8.0 301 haritası gerçek sitede denenir. Sonra yapılacaklar listesi, sonra Parça 3. Sprint 4 (AI) sonra konuşulur. Neden: AI'ın faydasını ölçmek için haritanın gerçek sitede neyi kaçırdığını bilmek gerekir.
- v0.8.1: Sprint 4 ön görüşmesi (11 Ekim 2026, karar değil, not). Fiyat (1M token, girdi/çıktı): Haiku 5.5 $0.10/$0.50, Sonnet 5.5 $2/$10, Opus 5.5 $4/$20. Batch API %50 indirim. Tahmin: 2.000 sayfa title/meta Haiku ile yaklaşık $0.43, Sonnet ile $8.60. Öneri: ilk AI özelliği 301 eşleştirmede anlam benzerliği. Aylık üst sınır Console workspace sınırı ile olur (Render diski kalıcı değil, uygulama sayacı sıfırlanır). Render'daki anahtar Cihan'ındır, Render'dan yapılan AI işleri Cihan'a yazılır. SDK gerekmez (Node 20 fetch). Fiyatları Sprint 4 başında tekrar kontrol et.
- v0.8.1: Arkadaş ayrı branch'te çalışır ve Pull Request açar. Kullanıcı kontrol eder ve merge eder. `main` dalına doğrudan yazılmaz.

- v0.8.0: Adım sırası değişti (kullanıcı onayladı): Proje → Tarama → Eşleştirme → 301 haritası → Yapılacaklar → (sonra) Canlıya çıkış → Canlı doğrulama. Neden: Yapılacaklar haritaya bağlıdır ("301 kurun" mu, "sayfayı oluşturun" mu).
- v0.8.0: Haritaya giren sayfalar: bölüm kuralı ile taşınan ve hedefi var olan sayfalar ("Kural", kendiliğinden), yeni adresi olmayan sayfalar (Kayboldu, Hedef yok, Bölüm kaldırıldı, hedefi kırık yönlendirme). Aynı yolda açılan veya doğru yönlenen sayfa haritaya girmez.
- v0.8.0: Öneri puanı 0-100. İki parça: alan puanı (slug 0.4, title 0.3, H1 0.15, içerik 0.15; eksik alan hesaba girmez) ve bütün kelimelerin tek torba benzerliği (`bagWeight` 0.5). Kelime ağırlığı nadirliğe göredir (IDF): yeni sayfalarda ve eski sayfalarda çok geçen kelime (istanbul, prosedur) az sayar. Benzerlik: yarı Dice, yarı daha iyi kapsanan tarafın kapsama oranı (kısa yeni slug `/facelift` uzun eski slug `facelift-turkey` ile güçlü eşleşir).
- v0.8.0: Kelime eşleşmesi: aynı kelime 1, ortak önek (en az 5 harf, kısa kelimenin %75'i) 0.8, yakın yazım (ilk harf aynı, düzenleme benzerliği en az %70) 0.7. Türkçe harfler ve aksanlar sadeleşir (ğ→g, ı→i, à→a). Sayılar ve `stopWords` puana girmez.
- v0.8.0: Aynı bölüm bonusu: bir eski bölümün iyi eşleşmelerinin çoğu tek yeni bölüme gidiyorsa (en az 2 eşleşme, %60) o bölümdeki adaylar +10 puan alır (/prosedur/ → /procedures/).
- v0.8.0: Bölüm kararı (kural bir siteye gidiyorsa) aramayı o siteye sınırlar. Türkçe sayfa için İngilizce sayfa önerilmez.
- v0.8.0: Ana sayfa, noindex sayfa ve yönlendirme aday olmaz. Araç ana sayfaya toplu 301 önermez (soft 404). Öneri yoksa kullanıcı adres seçer veya 410 verir.
- v0.8.0: Hız: aday arama kelime dizini ile yapılır. Aday sayfaların %30'undan fazlasında geçen kelime aramada kullanılmaz. Her eski sayfa için en fazla `maxScored` (40) aday tam puan alır.
- v0.8.0: Projede sadece kullanıcı kararları saklanır (`project.map`: eski yol → `{ site, path }`, `{ url }` veya `{ gone }`, `src`: oneri/elle). Öneriler her eşleştirmede tekrar hesaplanır. Kararı değiştirmek için `POST /map` kullanılır. Proje `PUT` haritayı değiştirmez (tarayıcıdaki eski kopya yeni kararı silmez). Silinen sitenin kararları düşer. "Projeyi indir" ve "Proje yükle" kararları taşır.
- v0.8.0: Yeni URL canlı alan adı ile yazılır: geçecek site için eski alan adı, ek site için projede yazılan "canlı alan adı". Canlı alan adı yoksa tarama adresi yazılır ve ekran uyarır.
- v0.8.0: Onaylanan hedef son taramada yoksa satır uyarı verir. Artık gerekli olmayan karar (eski sayfa yok veya sayfa bulundu) listeye girmez; ekran sayısını yazar.
- v0.8.0: CSV sadece son listeyi verir: Kural ve Onay satırları 301, 410 satırları boş yeni URL ile. UTF-8 BOM eklenir (Excel Türkçe harfleri doğru açar). `=`, `+`, `-`, `@` ile başlayan değerin önüne `'` eklenir (CSV formül koruması). Excel'deki "301 haritası" sayfası bütün satırları durumları ile verir.
- v0.8.0: "Bulunamadı" bölümü artık sıradaki işi engellemez. 301 haritası her sayfa için öneri verir. Bölüm başka siteye gidiyorsa kullanıcı siteyi seçer, bu seçim aramayı o siteye sınırlar.
- v0.8.0: Yeni bağımlılık yok. Benzerlik hesabı (IDF, Dice, düzenleme mesafesi) kendi kodumuzdur.

- v0.7.1: "Bulunamadı" ile "kaldırıldı" ayrıdır. Öneri motoru "Bölüm kaldırıldı" önermez. Hiçbir taşıma bölümü bulamazsa öneri `notFound: true` alır, bölüm "Karar verin" der, satır "Bulunamadı · Adresler değişmiş olabilir" yazar. "Bölüm kaldırıldı" seçeneği listede kalır, kullanıcı seçer.
- v0.7.1: Bazı sayfaları bulan en iyi taşıma ipucu olur ("Öneri: Türkçe · /tr/ kalkar"). İpucu kendiliğinden uygulanmaz. Bölümün kendi ana sayfası (`/fr` → `/`) kanıt sayılmaz, çünkü her sitede kök sayfa vardır. İpucu için en az bir başka sayfa bulunmalı.
- v0.7.1: Bölüm satırı açılır ("Sayfaları göster"). Her eski sayfa durumu ve adresi ile listelenir. Bulunan sayfa yeni adresini, bulunamayan sayfa aranan adresi ve nedenini gösterir. Bulunamayanlar önce gelir. Liste sınırı `compare.sectionPageLimit` (200), bütün liste Excel'de. API: `sections[].pageList`, `sections[].more`.
- v0.7.1: Etiket rengi: yeşil = sayfa yerinde (aynı, içerik değişti, yönleniyor, 301 kurulu). Amber = iş gerekli (301 eksik, hedef yok, bulunamadı, linksiz, kontrol edilemedi, bölüm kaldırıldı).
- v0.7.1: İki sayı, iki etiket. Seçim listesinde "taramada 3 / 7" (sadece tarama, istek yok). Sonuç sütununda "3 / 7 bulundu" (araç her adresi tek tek istedikten sonra). "Sonuç ?" açıklaması farkı anlatır. Tek sayıya indirilmedi: seçenek sayıları istek atmadan hesaplanır.
- v0.7.1: "Diğer sayfalar" yerine "Kök ve küçük bölümler" (yanında "?" açıklaması).
- v0.7.1: Mobil taşma düzeltmesi: adım çubuğundaki gizli `.sr` etiketleri (position: absolute) sayfayı 909 px genişletiyordu (v0.7.0 hatası). `.steps` artık `position: relative`.

- v0.7.0: Model düzeltmesi. Başka yola veya başka siteye taşınan sayfa artık "Aynı kaldı" sayılmaz. İki kontrol: hedef sayfa var mı, eski yol "eski alan adına geçecek site" üzerinde hedefe 301 veriyor mu. Sonuç: "Hedef hazır, 301 kurulu" (`moved`), "Hedef hazır, 301 eksik" (`no301`), "Hedef yok" (`notarget`). Korunan oran `moved` sayfaları da sayar. Kural istatistiğinde `no301` "bulundu" sayılır (hedef var).
- v0.7.0: 301 kontrolü Location başlığına göre yapılır. Geçecek sitede sadece aynı hosttaki adımlar izlenir. Başka hosta giden ilk adımda durulur, çünkü hedef site canlıda olmayabilir. Kabul edilen 301 hedefi: hedef sitenin tarama alan adı, projede yazılan "canlı alan adı" veya (hedef geçecek site ise) eski alan adı. Yol eşleşir ama alan adı bilinmiyorsa "301 eksik" olur ve "canlı alan adını projeye yazın" der. İstekler sadece taranan sitelere gider (SSRF yüzeyi büyümez).
- v0.7.0: Geçecek site taramasında eski yol yönlendirme olarak varsa (link ile bulunduysa) istek atılmaz, tarama sonucu kullanılır.
- v0.7.0: Proje `crawls/projects/<id>.json` dosyasında durur (crawls/ zaten .gitignore ve .dockerignore içinde). Yazma atomiktir: önce geçici dosya, sonra rename. Aynı projeye yazmalar sıraya girer.
- v0.7.0: Projede kural hedefi site anahtarıdır (`heir`, `s1`…), alan adı değildir. Motor için sitenin tarama alan adına çevrilir. Staging adresi değişse de kural geçerli kalır.
- v0.7.0: Tarama düğmesi taramayı başlatır, proje `pendingCrawlId` tutar. Tarama bitince `crawlId` yazılır. Hata olursa `lastError` yazılır ve eski tarama korunur. Site durumu: taranmadı, taranıyor, tamam, silinmiş, adres değişti. Proje ekranı taranırken 2 saniyede bir sunucuya sorar (SSE yerine basit).
- v0.7.0: Eşleştirme iki geçişte çalışır. Önce istek atmadan öneriler bulunur. Taşıma önerisi (bölüm başka yerde bulunur) kararsız bölüme uygulanır ve "Öneri" etiketi alır, kaydedilmez. "Bölüm kaldırıldı" önerisi uygulanmaz: bölüm "Karar verin" der ve amber "Öneri: …" etiketi alır. Kullanıcı seçince bölüm kuralı kaydedilir.
- v0.7.0: Bölüm tablosu ilk yol parçasına göre gruplar (en az `suggestMinPages` sayfa). Küçük gruplar "Diğer sayfalar" (`/*`) satırına girer. Her seçenek taramalarda bulduğu sayfa sayısını gösterir (istek atmaz).
- v0.7.0: "Karşılaştır" ekranı kaldırıldı. Yerine taşıma projesi geldi. Serbest kural editörü Eşleştirme adımında "Gelişmiş" altında. `#/compare` linki giriş ekranını "Taşıma projesi" seçili açar. `/api/compare` API olarak kaldı.
- v0.7.0: Giriş ekranından eski/yeni etiket seçimi kaldırıldı. Proje taramaları etiketi kendisi alır (eski site `eski`, diğerleri `yeni`). Kenar çubuğu: önce projeler, sonra projeye bağlı olmayan taramalar.
- v0.7.0: v0.6.1 tarayıcı kuralları (localStorage) proje kuralsız iken "Projeye aktar" ile aktarılır. Hedef alan adı projede yoksa kural atlanır ve kullanıcıya yazılır.
- v0.7.0: "Projeyi indir" sadece tanımı verir (sonuç ve sunucu alanları yok). "Proje yükle" yeni proje kimliği verir. Tarama kimlikleri dosyada kalır; taramalar sunucuda yoksa proje "Silinmiş: Tekrar tara" der.
- v0.7.0: Kural metninde "ana hedef" kalktı. Motor, geçecek sitenin alan adını yazar (`/en/* → staging.ornek.com/*`).

- Crawler'ı Crawlee yerine kendimiz yazdık: her redirect hop'unu kaydetmek (Faz 3 için şart) ve bağımlılığı az tutmak için.
- Sitemap'teki URL'ler link taraması bittikten sonra taranır. Böylece yetim sayfa ve doğru derinlik bulunur.
- www ve www olmayan host aynı site sayılır.
- Eski Türkçe siteler için windows-1254 / iso-8859-9 çözümlenir.
- İçerik kopyası "ana içerik" üzerinden ölçülür (header/nav/footer/aside hariç).
- Benzer içerik eşiği simhash mesafesi 5 (3, 300 kelimelik sayfalarda gerçek benzerleri kaçırdı). 5.000 rastgele sayfada yanlış alarm 0.
- Sağlık skoru = kritik sayfa sorunu olmayan URL oranı. Site geneli kritik sorun varsa skor en fazla 40.
- v0.4.3: Proje kişisel projedir. RNG İstanbul ile ilgisi yoktur. Ad "SEO Audit", paket ve depo adı `seo-audit`. User-Agent `SEO-Audit/<sürüm>`. Renkler (grafit + kırmızı) sadece tasarım tercihidir, bir marka kimliği değildir.
- v0.6.0 (Sprint 3, Parça 1): Sprint 3 dört parçaya bölündü: 1 karşılaştırma ekranı, 2 301 haritası önerisi, 3 canlıya çıkış kontrolü, 4 canlıda 301 doğrulama. Her parça ayrı sürüm.
- v0.6.0: Eski ve yeni tarama URL yoluna göre eşleşir (host farklı olabilir: canlı ve staging). Sondaki / yok sayılır, yüzde kodlu yol çözülür. Büyük/küçük harf farkı ayrı yol sayılır (Parça 2 benzerlik ile yakalar).
- v0.6.0: Sadece eski sitede 200 veren HTML sayfalar karşılaştırılır. Eski sitedeki yönlendirmeler eski sayfa sayılmaz.
- v0.6.0: Yeni tarama sadece yeni sitenin linklerini izler; eski URL'ler genelde sadece 301 olarak yaşar. Bu yüzden yeni taramada bulunmayan her eski yol yeni hostta tek tek istenir (yoklama). Sonuç: yönleniyor, hatalı hedefe yönleniyor, açılıyor ama linksiz, kayboldu veya kontrol edilemedi.
- v0.6.0: Yoklama staging şifresini göndermez (tarama şifresi kayıtta saklanmaz). Şifreli staging'de 401 "kontrol edilemedi" olur. Yayın modunda yoklama da SSRF korumasından geçer.
- v0.6.0: İçerik kaybı: title, meta description veya H1 boşaldıysa, ya da indexlenebilir sayfaya noindex eklendiyse. Farklı metin "değişti" sayılır, kayıp sayılmaz.
- v0.6.0: Karşılaştırma sonucu sunucu belleğinde tarama çifti başına saklanır (en fazla 20). Yoklama tekrar çalışmaz.
- v0.6.0: Kaybolan listesi önem sırasındadır: önce indexlenebilir, sonra eski sitede çok iç link alan sayfa.
- v0.7.0 planı: Proje kaydı sunucuda `crawls/` yanında JSON dosyası olur (veritabanı yok kuralı korunur). Projede taramaların sonucu değil, sadece tanım durur: siteler, roller, tarama kimlikleri, kurallar. Render diski kalıcı olmadığı için "Projeyi indir" ve "Proje yükle" (JSON) gelir. Taramalar silinirse proje ekranı "Tarama yok: Tara" der; tanım kalır, tekrar tarama tek tıktır. Sadece tarayıcıda saklamak seçilmedi: başka tarayıcıda ve arkadaş ile paylaşımda proje görünmez. Kalıcı çözüm sonra: Render kalıcı disk (ücretli) veya dış depolama.
- v0.6.1: Yol kuralı = eski yol deseni → hedef site + yeni yol (`/tr/* → tr.ornek.com /*`). `*` sadece sonda olur. `/tr/` yazılırsa `/tr/*` okunur. En uzun eski yol önce uygulanır. Kurala girmeyen yol ana hedefte aynı yolda aranır.
- v0.6.1: Çoklu hedef: bir eski tarama en fazla 4 yeni tarama ile karşılaştırılır (`rules.json` → `compare.maxTargets`). İlk yeni tarama ana hedeftir. Yoklama her eski adresi kuralın hedef sitesinde ister. Yeni sayfalar her hedef için ayrı bulunur.
- v0.6.1: Kural hedefi tarama kimliği değil, alan adıdır (www yok sayılır). Staging tekrar tarandığında kural geçerli kalır. Kuralın alan adı seçili taramalarda yoksa sayfalar "Kontrol edilemedi" olur; yoklama başka hosta gitmez (SSRF yüzeyi büyümez).
- v0.6.1: "Bölüm kaldırıldı" kuralı (`drop`): sayfa ana hedefte aynı yolda aranır. Yönleniyorsa "Yönleniyor", bulunmazsa "Kayboldu" yerine "Bölüm kaldırıldı" grubuna girer. Korunan oranı artırmaz. 301 veya 410 yine gerekir.
- v0.6.1: Kurallar sunucuda saklanmaz. Arayüz kuralları tarayıcıda (localStorage) eski sitenin alan adına göre saklar ve API'ye `rules` sorgu parametresi ile gönderir. Sebep: Render diski kalıcı değil, Excel linki de aynı parametreleri taşır. Karşılaştırma önbelleği kuralları da anahtara katar.
- v0.6.1: Desen önerisi: eski sayfalar ilk yol parçasına göre gruplanır (en az `suggestMinPages` sayfa). Her grup için her hedefte üç taşıma denenir: aynı yol, öneki kaldır, hedefin bir öneki ile değiştir. Öneri, taramadaki sayfalara bakar (yoklama yapmaz). Grubun en az `suggestMinRatio` oranını bulmalı ve mevcut durumdan en az `suggestMinPages` fazla sayfa bulmalı. Hiçbir taşıma bulamazsa "bölüm kaldırıldı" önerilir. Kuralı olan grup tekrar önerilmez.
- v0.6.1: Açıklama: her satırda kontrol edilen URL, uygulanan kural ve yapılacak iş (`todo`) yazılır. Yönlendirmede hatalı hedef, zincir (1'den fazla adım) ve 301/308 dışı status düzeltme ister. Her kuralın yanında sayfa ve bulunan sayısı gösterilir.
- v0.6.1: Testler müşteri alan adı kullanmaz (`eski.com`, `tr.ornek.com`). Depo herkese açıktır.
- v0.5.0: Araç Render ücretsiz planında yayınlanır (render.yaml, Docker). GitHub Pages kullanılmaz: sadece statik sayfa yayınlar, tarama sunucu ister.
- v0.5.0: Yayın modu PUBLIC_MODE=1 ile açılır. Yerel kullanım değişmez: test sitesi 127.0.0.1 üzerinde çalışmaya devam eder.
- v0.5.0: Yayın modunda APP_USER ve en az 10 karakterli APP_PASS zorunludur. Yoksa sunucu başlamaz.
- v0.5.0: SSRF koruması (src/netguard.js) her isteği ve yönlendirmenin her adımını kontrol eder: özel IPv4/IPv6 aralıkları, localhost, .internal, .local, http dışı protokoller. Ek kontrollerde yönlendirmeler artık elle izlenir. Engellenen kaynak "kırık" sayılmaz.
- v0.5.0: Bilinen sınır: DNS rebinding tam kapalı değil (adres istekten önce kontrol edilir). Kapatmak için undici dispatcher ile bağlantı anında kontrol gerekir; yeni bağımlılık ister.
- v0.5.0: Yayın limitleri rules.json → yayin: 2.000 URL, aynı anda 1 tarama. Ücretsiz plan 512 MB bellek verir.
- v0.5.0: Ücretsiz planda disk kalıcı değildir. EPHEMERAL_STORAGE=1 arayüzde uyarı gösterir. Docker imajı root olmayan kullanıcı ile çalışır.
- v0.4.3: Depo Public kalır, çünkü bir arkadaş ile paylaşılır. Claude kodu her sohbette depodan klonlar; Project ↔ GitHub senkronu gerekmez.
- v0.4.2: Proje GitHub'a taşındı (private depo). Önceki karar "GitHub kullanma" idi; dosya alışverişi çok adım aldığı için değişti. Kodun tek kaynağı GitHub deposudur. KAYNAK_KOD.md depoya girmez.
- Denetim, `rules.json` değişince eski taramalar açılırken otomatik tekrar çalışır (configHash).
- Sprint 2: Ek kontroller taramadan sonra ayrı adım olarak çalışır. Arayüz ve CLI'da varsayılan açık, kütüphanede (`crawl()`) varsayılan kapalı.
- Sprint 2: 401, 403, 429, 999 ve zaman aşımı "kırık" sayılmaz. Bunlar genelde bot korumasıdır (LinkedIn 999, Cloudflare 403).
- Sprint 2: Önce HEAD gönderilir. HEAD 4xx/5xx dönerse `GET Range: bytes=0-0` ile tekrar denenir. Boyut başlığı yoksa görsel için aynı GET kullanılır.
- Sprint 2: DNS hatası veren alan adı (ENOTFOUND) bir kez sorgulanır. Aynı hosttaki diğer URL'ler bu sonucu alır.
- Sprint 2: Staging şifresi (`auth`) sadece taranan siteye gönderilir, dış hostlara gönderilmez.
- Sprint 2: Site sürümleri kontrolü, sürümün son URL'sini ana adresin son URL'si ile karşılaştırır (`origin + '/'`). Sürüm 200 dönerse kopya site (kritik). Geçici yönlendirme, fazladan adım veya sertifika hatası uyarıdır.
- Sprint 2: Sadece sertifika hataları (CERT, SELF_SIGNED, VERIFY, ALTNAME) "sertifika hatası" sayılır. Protokol hataları (ERR_SSL_PACKET_LENGTH_TOO_LONG: https portunda düz http) ve ECONNREFUSED sayılmaz.
- Sprint 2: SSL sertifikası `tls.connect` ile `rejectUnauthorized: false` olarak okunur. Böylece süresi dolmuş veya self-signed sertifika da raporlanır.
- Sprint 2: Sıkıştırma ek istek gerektirmez. Taramada `content-encoding` başlığı kaydedilir. Test sitesi her HTML sayfayı gzip ile gönderir, sadece `/sikistirmasiz` sayfasını göndermez.
- Sprint 2: Testler internete çıkmaz. Dış linkler `.invalid` alan adı kullanır (RFC 2606). HTTPS testi 2046'ya kadar geçerli self-signed sertifika kullanır. `NODE_TLS_REJECT_UNAUTHORIZED=0` sadece test sürecinde ayarlanır.
- Arayüz (v0.4.1): Landing page uygulamanın giriş ekranıdır, aynı Node sunucusunda çalışır. Ayrı, herkese açık tanıtım sayfası yapılmadı: sunucuyu internete açmak SSRF ve şifre riski getirir.
- Arayüz (v0.4.1): Koyu tema. Zemin siyah değil grafit (#1C1F22). Gri yapıyı taşır. Kırmızı sadece ana buton ve hatalar içindir. Amber uyarı ve redirect, yeşil "sorun yok" içindir.
- Arayüz (v0.4.1): Tek yazı ailesi Archivo (Google Fonts). Başlıklar geniş kesim (font-stretch 125%), ağırlık 800. Font yüklenmezse system-ui kullanılır.
- Arayüz (v0.4.1): Giriş ekranında tek hareket var: URL alanının altındaki tarama şeridi bir kez dolar. prefers-reduced-motion açıksa hareket yok.
- Arayüz (v0.4.1): Giriş ekranındaki kategori ve kural sayıları /api/rules ile gelir. rules.json içinde kapatılan kurallar sayılmaz.
- Sprint 2: llms.txt kuralı "Bilgi" önemindedir. Dosya zorunlu değildir. Site hiç yanıt vermezse kural tetiklenmez.

## Proje dosyaları

Kodun tek kaynağı GitHub deposudur: https://github.com/Cihanpehlivan/seo-audit (Public). Depo bir arkadaş ile paylaşılır.

- `CLAUDE.md` — bu dosya: amaç, mimari, kurallar, durum, karar günlüğü. Depoda durur.
- `KAYNAK_KOD.md` — artık gerekmez. Depoya girmez. `npm run bundle` komutu yedek olarak durur.
- Depoya asla gizli bilgi koyma: `.env`, API anahtarı, staging şifresi, müşteri verisi, tarama sonucu (`crawls/`). Depo herkese açıktır.

## Çalışma döngüsü

Sohbette (claude.ai):

1. Kullanıcı yeni sohbet açar ve görevi yazar. Dosya yüklemez.
2. Claude depoyu klonlar: `git clone https://github.com/Cihanpehlivan/seo-audit.git`. Sonra `npm install` ve `npm test` çalıştırır. Testler geçmeden geliştirmeye başlama. Klonlama çalışmazsa kullanıcıdan depoyu zip olarak ister (GitHub → Code → Download ZIP).
3. Görevi bu dosyadan ve kullanıcıdan al. Kodu yaz, test sitesine yeni sayfalar ekle, `npm test` çalıştır.
4. Arayüz değiştiyse ekran görüntüsü ile kontrol et (masaüstü 1440 px ve mobil 390 px).
5. İş sonunda: bu dosyadaki Durum ve Karar günlüğü bölümlerini güncelle, `package.json` sürümünü artır. Kullanıcıya görünen özellik değiştiyse `README.md` içindeki ilgili bölümü de güncelle. README başlığına sürüm yazma.
6. Kullanıcıya bir zip ver (`seo-audit-vX.Y.Z.zip`). Zip sadece değişen ve yeni dosyaları, depodaki klasör yapısı ile içerir. Zip kökünde iki yardımcı dosya olur: `COMMIT.txt` (ilk satır commit mesajıdır) ve silinecek dosya varsa `SIL.txt` (her satır bir yol). Silinecek dosyaları ve commit mesajını sohbette de yaz. Zip `.github/` klasörünü içermez (iş akışı bunu reddeder).
7. Kullanıcı zip dosyasını AÇMADAN deponun kök klasörüne yükler (Add file → Upload files) ve commit yapar. `.github/workflows/guncelle.yml` iş akışı (v0.10.3) zip dosyasını açar, dosyaları doğru klasörlere yazar, `SIL.txt` içindeki dosyaları siler, `npm ci` ve `npm test` çalıştırır ve sonucu commit eder. Zip, `SIL.txt` ve `COMMIT.txt` depoda kalmaz. Testler geçmezse depo değişmez (zip kökte kalır, Actions sekmesi kırmızı olur). Gizli dosyalar da zip ile gelir; ayrıca metin vermek gerekmez. Sonraki sohbette Claude kök klasörde zip kalıp kalmadığını ve son iş akışının sonucunu kontrol eder (kökte zip varsa uygulama başarısız olmuştur).

Claude Code ile (masaüstü): Claude yerel depo klasöründe doğrudan çalışır, commit yapar. Zip ve 6-7. adımlar gerekmez. Push kullanıcı onayı ile yapılır.

8. Kullanıcı gerçek bir sitede dener ve geri bildirim verir. Eşikler `rules.json` ile kalibre edilir.

## İki kişi çalışma kuralları

Depoda iki kişi çalışır: kullanıcı (Cihan) ve bir arkadaş. Arkadaş Claude kullanmaz.

Arkadaş:
1. Her iş için `main` dalından yeni bir branch açar. `main` dalına doğrudan yazmaz.
2. İş sonunda bu dosyadaki Durum ve Karar günlüğü bölümlerini günceller.
3. `npm test` çalıştırır. Testler geçmeden Pull Request açmaz.
4. Pull Request açar. Açıklamaya ne değiştiğini ve nasıl denediğini yazar.
5. Bu dosyadaki bütün kurallara uyar (eşikler `rules.json` içinde, yeni kural için test sayfası ve beklenti, yeni bağımlılık için gerekçe, Türkçe kısa metin).

Kullanıcı (Cihan):
1. Pull Request kontrolünü Claude ile yapar.
2. Claude branch'i klonlar: `git clone -b <branch> https://github.com/Cihanpehlivan/seo-audit.git`.
3. Claude `npm install` ve `npm test` çalıştırır.
4. Claude değişikliği bu dosyadaki kurallara göre inceler: testler, `/temiz` sayfası, eşikler, bağımlılık, XSS (`esc()`), gizli bilgi, Durum ve Karar günlüğü güncel mi. Arayüz değiştiyse ekran görüntüsü alır (1440 px ve 390 px).
5. Claude bulguları listeler. Kullanıcı merge eder veya değişiklik ister.

Ortak kurallar:
- Aynı anda iki kişi aynı dosyada büyük değişiklik yapmaz. İş başlamadan kim neyi yapıyor, kısaca konuşulur.
- `package.json` sürümünü merge sırasında kullanıcı belirler. İki branch aynı sürüm numarasını almaz.
- Depoya gizli bilgi girmez. Her kişi kendi `.env` dosyasını kullanır.
